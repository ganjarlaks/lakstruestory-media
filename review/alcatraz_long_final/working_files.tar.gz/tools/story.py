# Shot map for the Alcatraz LTS long. Pools are consumed in order (no span is used twice).
SRC = "/dev/shm/alc/src"; IMG = "/dev/shm/alc/img"
CL = {"m1": f"{SRC}/m1.mp4", "n1": f"{SRC}/n1.mp4", "n2": f"{SRC}/n2.mp4", "m3": f"{SRC}/m3.mp4", "f919": f"{SRC}/f919.mp4", "ftrailer": f"{SRC}/ftrailer.mp4"}
# crops remove letterbox bars / the Periscope timecode band
CROP = {"m1": "crop=632:468:4:4", "n1": "crop=642:384:106:0", "n2": "crop=480:360:80:0", "m3": "crop=496:360:74:0", "f919": "crop=1428:1080:246:0", "ftrailer": "crop=956:720:162:0"}
FILMLAB = "Film: Escape From Alcatraz (1979), dramatization, not the real event"
POOLS = {
 # name: (clip, class, label, [(start,end),...])
 "M1ISL": ("m1", "real", "Alcatraz Island seen from a boat, c. 1938 (Prelinger Archives)", [(78, 104), (132, 142), (186, 218)]),
 "M1BOAT": ("m1", "real", "Boats and ferries on San Francisco Bay, c. 1938 (Prelinger Archives)", [(108, 120), (150, 166), (168, 184), (222, 242)]),
 "N1": ("n1", "real", "San Francisco Bay and Alcatraz, 1967 (TV show Discovery, via Periscope Film)", [(250, 281), (283, 304), (310, 335), (365, 380)]),
 "N2A": ("n2", "real", "Archival film of the prison, undated (in the 1986 documentary Alcatraz, David Watts Productions)", [(527, 545), (577, 605), (607, 625), (627, 634), (660, 682), (700, 703), (1015, 1034), (1037, 1048), (1050, 1068), (1090, 1103)]),
 "N2MESS": ("n2", "real", "Archival film of the prison, undated (in the 1986 documentary Alcatraz, David Watts Productions)", [(1070, 1088)]),
 "N2EXT": ("n2", "real", "Alcatraz as filmed in 1986, empty (documentary Alcatraz, David Watts Productions)", [(32, 60), (1160, 1195), (1206, 1256), (1340, 1376), (1410, 1424)]),
 "N2INT": ("n2", "real", "Inside Alcatraz as filmed in 1986, empty (documentary Alcatraz, David Watts Productions)", [(1258, 1296), (1298, 1318)]),
 "M3": ("m3", "real", "Inside the empty cell house, after the prison closed (American Archive of Public Broadcasting film, undated)", [(8, 30), (56, 72), (88, 100), (136, 150), (168, 180), (216, 232), (286, 334)]),
 "M3CELL": ("m3", "real", "Inside the empty cell house, after the prison closed (American Archive of Public Broadcasting film, undated)", [(200, 212), (272, 284), (336, 344)]),
 "F": ("f919", "film", FILMLAB, [(56, 64), (72, 74), (76, 90), (102, 110), (36, 50, 'ftrailer'), (71, 90, 'ftrailer'), (93, 110, 'ftrailer'), (111, 131, 'ftrailer'), (30, 34, 'ftrailer')]),
}
PAGES = {"A": (f"{IMG}/e0612_1.jpg", None), "B": (f"{IMG}/e0613_5.jpg", None), "C": (f"{IMG}/e0617_11.jpg", None)}
PLBL = {"A": "Evening Star, Washington, 12 Jun 1962, p. A-1 (Library of Congress)", "B": "Evening Star, Washington, 13 Jun 1962, p. A-5 (Library of Congress)", "C": "Sunday Star, Washington, 17 Jun 1962, p. A-11 (Library of Congress)"}
def V(pool, w=1.0): return ("v", pool, w)
def P(pg, win, end=None, w=1.0): return ("p", pg, win, end, w, PLBL[pg])
WA_HEAD = (380, 1800, 900, 506)     # 12 Jun headline "3 Bank Robbers Flee Alcatraz With Aid of Sharpened Spoon"
WA_TXT = (380, 1960, 620, 400)      # 12 Jun article text
WB_TXT = (640, 760, 640, 360)        # 13 Jun p5 article text ("Possibly on Island")
WB_TXT2 = (640, 880, 640, 330)      # 13 Jun p5 warden version text (no photo)
WC_HEAD = (100, 820, 1000, 563)      # 17 Jun p11 "Robber With High IQ"
M = {
 "C1": [V("N1"), V("M1ISL")],
 "C2": [V("M3CELL"), V("M3CELL")],
 "C3": [V("N2EXT"), V("N2EXT"), V("M1ISL")],
 "1.1": [V("M1ISL"), V("M1ISL")],
 "1.2": [V("N1"), V("N1")],
 "1.3": [V("N2A")],
 "1.4": [V("N2A"), V("N2A")],
 "1.5": [P("B", WB_TXT, (640, 900), 1.1), V("M1BOAT")],
 "1.6": [P("A", WA_HEAD, (380, 1850), 1.2), V("N2A")],
 "1.7": [V("N2A"), V("N2A")],
 "1.8": [V("N2A")],
 "1.9": [P("C", WC_HEAD, (100, 900), 1.1), V("N2A")],
 "2.1": [V("M3"), V("M3")],
 "2.2": [V("M3"), V("M3")],
 "2.3": [V("N2MESS")],
 "2.4": [V("M3"), V("M3"), V("M3")],
 "2.5": [V("M3CELL")],
 "2.6": [V("M3CELL"), V("M3")],
 "2.7": [V("M3"), V("M3")],
 "2.8": [V("M1BOAT"), V("N1")],
 "2.9": [V("M1BOAT"), V("N1")],
 "2.10": [V("N2A"), V("N2A")],
 "2.11": [V("F"), V("F")],
 "2.12": [V("F"), V("F")],
 "3.1": [V("N2A"), V("N2A")],
 "3.2": [V("N2A"), V("N2A")],
 "3.3": [P("A", WA_TXT, (380, 2050), 1.1), V("M1ISL")],
 "3.4": [V("N2EXT"), V("N2EXT")],
 "3.5": [V("M1BOAT"), V("N1")],
 "3.6": [V("N1")],
 "3.7": [V("N1"), V("M1ISL")],
 "3.8": [V("N1"), V("M1ISL")],
 "3.9": [P("B", WB_TXT2, (640, 960), 1.1), V("N2A")],
 "3.10": [V("N2A"), V("N2A")],
 "4.1": [V("N2EXT")],
 "4.2": [V("N1"), V("N1"), V("M1ISL")],
 "4.3": [V("N2INT"), V("N2INT")],
 "4.4": [V("M3"), V("M3")],
 "4.5": [V("M3"), V("M3")],
 "4.6": [V("M3"), V("M3")],
 "4.7": [V("M3"), V("N2INT")],
 "4.8": [V("N2EXT"), V("N2INT")],
 "4.9": [V("M3"), V("M3")],
 "4.10": [V("N2EXT"), V("M3")],
 "Z1": [V("N1"), V("M1ISL"), V("N2EXT")],
 "Z2": [V("M1ISL"), V("M1ISL")],
}
BEATS = {"B2": [V("N1"), V("N1")], "B3": [V("M1BOAT"), V("M1BOAT")], "B4": [V("N2INT"), V("N2INT")],
 "F1": [V("F"), V("F")], "F2": [V("F"), V("F")], "F3": [V("F"), V("F")],
 "B8": [V("M1BOAT"), V("N1")], "B9": [V("M1ISL"), V("N1")], "B11": [V("N1"), V("M1ISL")]}
SEQ = [("card","open"),("line","C1"),("line","C2"),("line","C3"),
 ("card","1"),("line","1.1"),("line","1.2"),("line","1.3"),("line","1.4"),("beat","B2"),("line","1.5"),("line","1.6"),("line","1.7"),("line","1.8"),("line","1.9"),("beat","B3"),
 ("card","2"),("line","2.1"),("line","2.2"),("line","2.3"),("line","2.4"),("beat","B4"),("line","2.5"),("line","2.6"),("line","2.7"),("line","2.8"),("line","2.9"),("line","2.10"),("line","2.11"),("line","2.12"),("beat","F1"),("beat","F2"),("beat","F3"),
 ("card","3"),("line","3.1"),("line","3.2"),("line","3.3"),("line","3.4"),("beat","B8"),("line","3.5"),("line","3.6"),("line","3.7"),("line","3.8"),("beat","B9"),("line","3.9"),("line","3.10"),
 ("card","4"),("line","4.1"),("line","4.2"),("line","4.3"),("line","4.4"),("line","4.5"),("line","4.6"),("line","4.7"),("line","4.8"),("line","4.9"),("line","4.10"),("beat","B11"),("line","Z1"),("line","Z2"),("card","close")]
