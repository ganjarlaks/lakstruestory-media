#!/usr/bin/env python3
"""Marilyn Monroe long thumbnail 1280x720 (Gandhi/MLK/Saddam layout: B/W photo right, text left). usage: thumb_ml.py FRAME.png OUT.jpg [line1|line2|...]
Default lines = title option B ("Marilyn Monroe : Her Voice and the Three Days After")."""
import sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageOps,ImageEnhance
FD='/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf'
lines=(sys.argv[3] if len(sys.argv)>3 else "Marilyn|Monroe :|Her Voice and|the Three|Days After").split("|")
fr=Image.open(sys.argv[1]).convert('L').crop((210,0,960,720)); fr=ImageOps.autocontrast(fr,cutoff=1); fr=ImageEnhance.Contrast(fr).enhance(1.12)
h=720; w=int(fr.width*h/fr.height); fr=fr.resize((w,h),Image.LANCZOS).convert('RGB')
im=Image.new('RGB',(1280,720),(0,0,0)); im.paste(fr,(1280-fr.width+75,0))
a=np.asarray(im).astype(np.float32); x=np.arange(1280)[None,:,None]
m=np.clip((x-540)/80,0,1); im=Image.fromarray((a*m).clip(0,255).astype(np.uint8)); d=ImageDraw.Draw(im)
Y=(255,214,10); Wt=(255,255,255)
f=ImageFont.truetype(FD,36); d.text((65,60),'A TRUE STORY',font=f,fill=Y); w2=d.textlength('A TRUE STORY',font=f); d.line([(65,106),(65+w2,106)],fill=Y,width=4)
T=ImageFont.truetype(FD,70); n=len(lines); pitch=108 if n>=5 else 118
for i,tx in enumerate(lines):
    c=Y if i==n-1 else Wt
    for dx,dy in ((6,6),(5,5),(4,4)): d.text((71+dx,140+i*pitch+dy),tx,font=T,fill=(0,0,0))
    d.text((71,140+i*pitch),tx,font=T,fill=c); print(tx,d.textlength(tx,font=T))
im.save(sys.argv[2],quality=93)
