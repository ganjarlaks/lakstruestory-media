from PIL import Image,ImageDraw,ImageFont
import sys
FB="/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
FR="/usr/share/fonts/truetype/google-fonts/Poppins-Regular.ttf"
W,H=1920,1080
YEL=(255,214,10);WHT=(255,255,255);GRY=(165,165,172);BG=(0,0,0)
def font(p,s): return ImageFont.truetype(p,s)
def fit(d,text,path,size,maxw):
    while size>20:
        f=font(path,size)
        if d.textlength(text,font=f)<=maxw: return f
        size-=2
    return font(path,20)
def wrap(d,text,f,maxw):
    words=text.split();lines=[];cur=""
    for w in words:
        t=(cur+" "+w).strip()
        if d.textlength(t,font=f)<=maxw: cur=t
        else: lines.append(cur);cur=w
    if cur: lines.append(cur)
    return lines
def centered(d,y,text,f,fill):
    w=d.textlength(text,font=f); d.text(((W-w)/2,y),text,font=f,fill=fill)
def opening(path,title,place):
    im=Image.new("RGB",(W,H),BG);d=ImageDraw.Draw(im)
    centered(d,230,"A TRUE STORY",font(FB,52),YEL)
    f=font(FB,96);ls=wrap(d,title,f,1560);y=360
    for l in ls: centered(d,y,l,f,WHT);y+=125
    d.rectangle([(W-300)//2,y+25,(W+300)//2,y+31],fill=YEL)
    centered(d,y+75,place,font(FB,50),GRY)
    im.save(path)
def chapter(path,n,title):
    im=Image.new("RGB",(W,H),BG);d=ImageDraw.Draw(im)
    centered(d,360,f"CHAPTER {n}",font(FB,44),YEL)
    f=fit(d,title,FB,92,1600);centered(d,450,title,f,WHT)
    d.rectangle([(W-240)//2,600,(W+240)//2,605],fill=YEL)
    im.save(path)
def textcard(path,l1,l2,l3):
    im=Image.new("RGB",(W,H),(8,8,10));d=ImageDraw.Draw(im)
    centered(d,300,l1,font(FB,64),YEL)
    f=fit(d,l2,FB,84,1600);centered(d,430,l2,f,WHT)
    d.rectangle([(W-240)//2,570,(W+240)//2,575],fill=YEL)
    f3=fit(d,l3,FR,46,1600);centered(d,625,l3,f3,GRY)
    im.save(path)
def _top(d,punch,question):
    f=font(FB,48);y=90
    for l in wrap(d,punch,f,1700): centered(d,y,l,f,WHT);y+=62
    f=font(FR,36);y+=10
    for l in wrap(d,question,f,1780): centered(d,y,l,f,GRY);y+=50
    return y
def closing1(path,punch,question):
    im=Image.new("RGB",(W,H),BG);d=ImageDraw.Draw(im)
    _top(d,punch,question)
    im.save(path)
def closing2(path,punch,question,refs,note):
    # layout of channels/laks-true-story/CLOSING-FRAME.md section 5 (long): punch line + question stay on screen, references fade in under them
    im=Image.new("RGB",(W,H),BG);d=ImageDraw.Draw(im)
    y=_top(d,punch,question)
    d.rectangle([(W-700)//2,330,(W+700)//2,333],fill=YEL)
    centered(d,360,"RESEARCH REFERENCES",font(FB,40),YEL)
    y=450
    for r in refs: centered(d,y,r,fit(d,r,FR,46,1700),WHT);y+=72
    centered(d,985,note,font(FR,32),GRY)
    im.save(path)
def scrim(path):
    # gradient 0 -> 60% black from y650 to y840, held to bottom (RGBA)
    im=Image.new("RGBA",(W,H),(0,0,0,0));px=im.load()
    for y in range(H):
        a=0 if y<650 else (int(255*0.6*(y-650)/190) if y<840 else int(255*0.6))
        for x in range(0,W): px[x,y]=(0,0,0,a)
    im.save(path)
if __name__=="__main__": pass
