#!/usr/bin/env python3
"""Remove silent holes (<-36 dB RMS runs > 0.4 s, per 0.25 s windows) from bed.wav and crossfade the remaining pieces. usage: patchbed.py in.wav out.wav"""
import wave,sys,numpy as np
w=wave.open(sys.argv[1]); sr=w.getframerate(); x=np.frombuffer(w.readframes(w.getnframes()),np.int16).astype(np.float32)/32768; w.close()
h=int(0.25*sr); n=len(x)//h; TH=-36
db=np.array([20*np.log10(np.sqrt(np.mean(x[i*h:(i+1)*h]**2))+1e-9) for i in range(n)])
bad=db<TH
cut=[]; i=0
while i<n:
    if bad[i]:
        j=i
        while j<n and bad[j]: j+=1
        if (j-i)*0.25>=0.4: cut.append((max(0,i*h-int(0.3*sr)),min(len(x),j*h+int(0.3*sr))))
        i=j
    else: i+=1
print("cuts",[(round(a/sr,1),round(b/sr,1)) for a,b in cut])
pieces=[];p=0
MINP=3*int(1.5*sr)
for a,b in cut:
    if a-p>MINP: pieces.append(x[p:a])
    p=b
if len(x)-p>MINP: pieces.append(x[p:])
X=int(1.5*sr); t=np.linspace(0,np.pi/2,X); fo=np.cos(t)**1; fi=np.sin(t)
out=pieces[0]
for pc in pieces[1:]:
    seam=out[-X:]*fo+pc[:X]*fi
    out=np.concatenate([out[:-X],seam,pc[X:]])
o=wave.open(sys.argv[2],'wb'); o.setnchannels(1); o.setsampwidth(2); o.setframerate(sr); o.writeframes((np.clip(out,-1,1)*32767).astype(np.int16).tobytes()); o.close()
print("out",len(out)/sr)
