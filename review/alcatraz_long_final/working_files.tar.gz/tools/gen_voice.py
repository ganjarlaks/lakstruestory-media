import sys,os,time
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import torch, torchaudio as ta
_o=torch.load; torch.load=lambda *a,**k:_o(*a,**{**k,"map_location":torch.device("cpu")})
from chatterbox.tts import ChatterboxTTS
torch.set_num_threads(2)
from ttsprep import tts
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),"lines.py")).read())
out=sys.argv[1]; ref=sys.argv[2]; sel=sys.argv[3].split(",") if len(sys.argv)>3 and sys.argv[3] else None
os.makedirs(out,exist_ok=True)
from pathlib import Path
from huggingface_hub import hf_hub_download
from safetensors import safe_open
from chatterbox.tts import REPO_ID,Conditionals,S3GEN_SR
from chatterbox.models.t3 import T3
from chatterbox.models.s3gen import S3Gen
from chatterbox.models.voice_encoder import VoiceEncoder
from chatterbox.models.tokenizers import EnTokenizer
def sd_of(p,bf=None):
    d={}
    with safe_open(str(p),framework="pt") as f:
        for k in f.keys():
            t=f.get_tensor(k)
            if bf and k.startswith(bf) and t.is_floating_point(): t=t.to(torch.bfloat16)
            d[k]=t
    return d
for fp in ["ve.safetensors","t3_cfg.safetensors","s3gen.safetensors","tokenizer.json","conds.pt"]: lp=hf_hub_download(repo_id=REPO_ID,filename=fp)
ck=Path(lp).parent
ve=VoiceEncoder(); ve.load_state_dict(sd_of(ck/"ve.safetensors")); ve.eval()
torch.set_default_dtype(torch.bfloat16); t3=T3(); torch.set_default_dtype(torch.float32)
for n,mod in t3.named_children():
    if n!="tfmr": mod.float()
t3_state=sd_of(ck/"t3_cfg.safetensors","tfmr.")
if "model" in t3_state: t3_state=t3_state["model"][0]
for k,v in list(t3_state.items()):
    if not k.startswith("tfmr.") and v.is_floating_point(): t3_state[k]=v.float()
t3.load_state_dict(t3_state); del t3_state; t3.eval()
s3=S3Gen(); s3.load_state_dict(sd_of(ck/"s3gen.safetensors"),strict=False); s3.eval()
tok=EnTokenizer(str(ck/"tokenizer.json"))
conds=Conditionals.load(ck/"conds.pt",map_location=torch.device("cpu"))
m=ChatterboxTTS(t3,s3,ve,tok,"cpu",conds=conds)
tf=m.t3.tfmr
import gc; gc.collect()
tf.register_forward_pre_hook(lambda mod,a,k:(a,{**k,"inputs_embeds":k["inputs_embeds"].to(torch.bfloat16)} if k.get("inputs_embeds") is not None else k),with_kwargs=True)
def _post(mod,a,k,o):
    o.last_hidden_state=o.last_hidden_state.float()
    if getattr(o,'hidden_states',None) is not None: o.hidden_states=tuple(h.float() for h in o.hidden_states)
    return o
tf.register_forward_hook(_post,with_kwargs=True)
for i,c,tx in L:
    if sel and i not in sel: continue
    pf=f"{out}/{i}.wav"
    if os.path.exists(pf): continue
    t=tts(tx); ts=time.time()
    with torch.inference_mode(): wav=m.generate(t,audio_prompt_path=ref,exaggeration=0.3,cfg_weight=0.3)
    ta.save(pf+".tmp.wav",wav,m.sr); os.rename(pf+".tmp.wav",pf)
    print(i,len(tx.split()),"words",round(wav.shape[-1]/m.sr,2),"s audio",round(time.time()-ts),"s compute",flush=True)
print("BATCHDONE",flush=True)
