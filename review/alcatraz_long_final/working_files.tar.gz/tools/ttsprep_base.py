import re
ONES="zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
TENS="x x twenty thirty forty fifty sixty seventy eighty ninety".split()
def n2w(n):
    if n<20: return ONES[n]
    if n<100: return TENS[n//10]+("" if n%10==0 else "-"+ONES[n%10])
    if n<1000: return ONES[n//100]+" hundred"+("" if n%100==0 else " "+n2w(n%100))
    return n2w(n//1000)+" thousand"+("" if n%1000==0 else " "+n2w(n%1000))
def ordw(n):
    irr={1:"first",2:"second",3:"third",5:"fifth",8:"eighth",9:"ninth",12:"twelfth"}
    if n in irr: return irr[n]
    if n<20: return ONES[n]+"th"
    if n%10==0: return TENS[n//10][:-1]+"ieth"
    return n2w(n-n%10)+"-"+(irr.get(n%10) or ONES[n%10]+"th")
def year(n):
    if n<1900: return n2w(n)
    if 1900<=n<2000: return n2w(n//100)+" "+("oh-"+ONES[n%100] if n%100<10 and n%100 else (n2w(n%100) if n%100 else "hundred"))
    if 2000<=n<2010: return "two thousand"+("" if n==2000 else " "+ONES[n-2000])
    return "twenty "+n2w(n-2000)
MONTH=r"(January|February|March|April|May|June|July|August|September|October|November|December)"
TIMES={"01:23":"twenty-three minutes past one","14:00":"fourteen hundred","00:28":"twenty-eight minutes past midnight","01:03":"three minutes past one"}
RESP=[("Chernobyl","Chur-noh-bul"),("Kyiv","Keev"),("Pripyat","Pree-pyat"),("RBMK","R B M K"),("Slavutich","Slah-voo-tich"),("Legasov","Leg-ah-sov"),("Valery","Vuh-lair-ee"),("IAEA","I A E A"),("Caesium","See-zee-um"),("caesium","see-zee-um")]
def tts(t):
    for a,b in TIMES.items(): t=t.replace(a,b)
    for a,b in RESP: t=t.replace(a,b)
    t=re.sub(r"\b(\d{1,2}) "+MONTH,lambda m:f"the {ordw(int(m.group(1)))} of {m.group(2)}",t)
    t=re.sub(r"\b(\d+)(st|nd|rd|th)\b",lambda m:ordw(int(m.group(1))),t)
    t=re.sub(r"\b(1[0-9]\d\d|20\d\d)\b",lambda m:year(int(m.group(1))),t)
    t=re.sub(r"\b(\d+)\b",lambda m:n2w(int(m.group(1))),t)
    return t
if __name__=="__main__":
    exec(open("lines.py").read())
    for i,c,tx,*o in L: print(i,"|",tts(tx))
