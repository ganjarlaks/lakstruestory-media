#!/usr/bin/env python3
"""Word times per narration line: faster-whisper small.en transcript -> CTC forced alignment (tools/lts_sync.align) of that transcript -> map to display tokens.
usage: capsync.py VOICEDIR OUT.json   (runs in the venv /tmp/cb_venv: torch, torchaudio, faster_whisper). Result: {id: {"tokens":[[display,start,end],...],"wh":[[w,s,e],...]}}"""
import sys,os,re,json,difflib,subprocess,numpy as np
sys.path.insert(0,'/home/claude/production-house/channels/laks-true-story/tools'); sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import lts_sync as L
from lines import L as LINES
from ttsprep import tts as _tts
ONES="zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
TENS="x x twenty thirty forty fifty sixty seventy eighty ninety".split()
ORD={"1":"first","21":"twenty first","29":"twenty ninth","30":"thirtieth","5":"fifth","16":"sixteenth","22":"twenty second","28":"twenty eighth"}
def n2w(n):
    if n<20: return ONES[n]
    if n<100: return TENS[n//10]+("" if n%10==0 else " "+ONES[n%10])
    if n<1000: return ONES[n//100]+" hundred"+("" if n%100==0 else " "+n2w(n%100))
    if 1100<=n<2000 or 2010<=n<2100: return n2w(n//100)+(" "+(("oh "+ONES[n%100]) if n%100<10 else n2w(n%100)) if n%100 else " hundred")
    if n%1000==0: return ONES[n//1000]+" thousand"
    return ONES[n//1000]+" thousand "+n2w(n%1000)
def expand(tok):
    if re.search(r"\d",tok):
        t=_tts(tok); return [w.lower() for w in re.findall(r"[A-Za-z']+",t)]
    t=re.sub(r"[^A-Za-z0-9']","",tok)
    return [t.lower()] if t else []
def norm(w): return re.sub(r"[^a-z]","",w.lower())
def main(vd,out):
    from faster_whisper import WhisperModel
    wm=WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=2)
    res={}
    ONLY=os.environ.get('ONLY'); ONLY=ONLY.split(',') if ONLY else None
    for i,ch,text,*_ in LINES:
        if (ONLY and i not in ONLY) or (ch=="S" and not ONLY): continue
        p=f"{vd}/{i}.wav"; a=L.read16k(p)
        segs,_=wm.transcribe(a,word_timestamps=True,language='en',condition_on_previous_text=False,beam_size=5)
        wh=[(w.word.strip(),w.start,w.end) for s in segs for w in s.words]
        spoken=[]
        for w,s,e in wh:
            ex=expand(w) if re.search(r"\d",w) else [norm(w)]
            ex=[x for x in ex if x]
            for k,x in enumerate(ex): spoken.append((x,s+(e-s)*k/len(ex),s+(e-s)*(k+1)/len(ex)))
        sw=[x[0] for x in spoken]
        ali=L.align(a,[x.replace("'","") if x else "a" for x in sw])
        disp=text.split()
        dex=[];own=[]
        for k,tok in enumerate(disp):
            for x in expand(tok): dex.append(norm(x)); own.append(k)
        sm=difflib.SequenceMatcher(None,dex,[norm(x) for x in sw],autojunk=False)
        st={};en={}
        for a0,b0,n in sm.get_matching_blocks():
            for k in range(n):
                o=own[a0+k]; s0,e0=ali[b0+k]; st.setdefault(o,s0); en[o]=e0
        toks=[]
        last_e=0.0
        miss=0
        for k,tok in enumerate(disp):
            if k in st: toks.append([tok,st[k],en[k]]); last_e=en[k]
            else:
                miss+=1; toks.append([tok,None,None])
        # interpolate missing
        for k,t in enumerate(toks):
            if t[1] is None:
                l=max([x for x in range(k) if toks[x][2] is not None],default=None); r=min([x for x in range(k+1,len(toks)) if toks[x][1] is not None],default=None)
                s0=toks[l][2] if l is not None else ali[0][0]; e0=toks[r][1] if r is not None else ali[-1][1]
                nmiss=1+sum(1 for x in range(k+1,(r if r is not None else len(toks))) if toks[x][1] is None)
                t[1]=s0; t[2]=s0+(e0-s0)/nmiss
        res[i]={"tokens":toks,"wh":[[w,s,e] for w,s,e in wh],"ctc":[[w,a0,a1] for (w,_,_),(a0,a1) in zip(spoken,ali)],"unmatched":miss,"whisper_text":" ".join(w for w,_,_ in wh)}
        print(i,"unmatched",miss,"|",res[i]["whisper_text"][:90],flush=True)
    json.dump(res,open(out,"w"))
if __name__=="__main__": main(sys.argv[1],sys.argv[2])
