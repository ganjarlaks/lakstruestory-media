#!/usr/bin/env python3
"""LTS Alcatraz long builder (adapted from marilyn/tools_v2/mk_ml.py). usage: mk_alc.py WORK stage   stages: plan | segs | concat | audio | caps | final
No burned-in narration captions; only small top-left source labels (film clips get a boxed 'Film:' label for their whole duration). No real audio is used: music bed + narration only."""
import json, os, re, subprocess, sys, wave
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lines import L
import story, cards
from PIL import Image, ImageFilter, ImageEnhance
Image.MAX_IMAGE_PIXELS = None
W, H, FPS = 1920, 1080, 25
WORK = sys.argv[1]; STAGE = sys.argv[2]
os.chdir(WORK); os.makedirs("seg", exist_ok=True)
GAP = float(os.environ.get("GAP", "1.8")); CARD = 5.0; BEAT = float(os.environ.get("BEAT", "8.0"))
TITLE = os.environ.get("MTITLE", "Alcatraz : The famous escape")
PLACE = "San Francisco Bay · 1962"
CHAP = {"1": "The Rock", "2": "Spoons, Plaster and Paint", "3": "The Morning Count", "4": "What the Record Leaves Open"}
txt = {i: t for i, c, t, *_ in L}
PUNCH = txt["Z1"]; QUEST = txt["Z2"]
REFLIST = ["Evening Star, Washington, 12 to 17 Jun 1962 (Library of Congress)", "FBI history page: Alcatraz Escape; Bureau of Prisons: Alcatraz", "CBS News, Jan 2018 (the 2013 letter); KPIX, Jun 2017", "Film: Escape From Alcatraz (1979), Paramount, dramatization", "Prelinger Archives c. 1938; Discovery 1967; AAPB; Video Visits: Alcatraz"]
NOTE = "Full list with links in the description"
LOCK = ["flock", "/tmp/render.lock", "nice", "-n", "19"]
CL = story.CL
ENC = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p", "-r", str(FPS), "-an"]
def sh(cmd): subprocess.run(LOCK + cmd, check=True)
def wdur(i):
    w = wave.open(f"voice/{i}.wav"); d = w.getnframes() / w.getframerate(); w.close(); return d

def plan():
    ev = []; t = 0.0
    def add(k, d, **kw):
        nonlocal t; ev.append(dict(k=k, s=round(t, 3), e=round(t + d, 3), **kw)); t += d
    for typ, key in story.SEQ:
        if typ == "card":
            if key == "open": add("card", CARD, kind="open")
            elif key == "close": add("close2", CARD)
            else: add("card", CARD, kind="chap", ch=key)
        elif typ == "line":
            vd = wdur(key); add("line", vd + GAP, id=key, vd=vd)
        elif typ == "beat": add("beat", BEAT, id=key)
    json.dump(dict(events=ev, total=t), open("plan.json", "w"), indent=1)
    print("TOTAL %.1f s = %d:%05.2f" % (t, t // 60, t % 60)); return ev, t

_IMG = {}
def page(pg):
    if pg not in _IMG:
        f, aw = story.PAGES[pg]; im = Image.open(f).convert("L"); _IMG[pg] = (im, 1.0)
    return _IMG[pg]
def seg_card(path, d, png, fi=0.5, fo=0.5):
    if os.path.exists(path): return
    vf = f"fade=t=in:st=0:d={fi},fade=t=out:st={max(d - fo, 0.1):.2f}:d={fo},format=yuv420p"
    sh(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-framerate", str(FPS), "-i", png, "-t", f"{d + 0.5:.3f}", "-frames:v", str(int(round(d * FPS))), "-vf", vf] + ENC + [path])
def seg_pan(path, d, key, it, fadeout=0.0):
    if os.path.exists(path): return
    _, pg, win, end, wgt, lab = it
    im, s = page(pg); x, y, w, h = win; x2, y2 = end if end else (x, y)
    rx0, ry0 = min(x, x2), min(y, y2); rx1, ry1 = max(x, x2) + w, max(y, y2) + h
    f = min(1700 / (w * s), 960 / (h * s))
    reg = im.crop((int(rx0 * s), int(ry0 * s), int(rx1 * s), int(ry1 * s))).convert("RGB")
    reg = reg.resize((max(2, int(reg.width * f)), max(2, int(reg.height * f))), Image.LANCZOS)
    reg = ImageEnhance.Contrast(reg).enhance(1.08); regp = f"seg/r_{key}.png"; reg.save(regp)
    fw = min(int(w * s * f), reg.width - 2) // 2 * 2; fh = min(int(h * s * f), reg.height - 2) // 2 * 2
    xs, ys = (x - rx0) * s * f, (y - ry0) * s * f; xe, ye = (x2 - rx0) * s * f, (y2 - ry0) * s * f
    wc = im.crop((int(x * s), int(y * s), int((x + w) * s), int((y + h) * s))).convert("RGB").resize((W, H)).filter(ImageFilter.GaussianBlur(28))
    wc = ImageEnhance.Brightness(wc).enhance(0.42); bgp = f"seg/b_{key}.png"; wc.save(bgp)
    fo = f",fade=t=out:st={d - fadeout:.2f}:d={fadeout}" if fadeout else ""
    fc = (f"[1:v]crop={fw}:{fh}:x='min({xs:.1f}+({xe:.1f}-{xs:.1f})*t/{d:.3f},iw-{fw})':y='min({ys:.1f}+({ye:.1f}-{ys:.1f})*t/{d:.3f},ih-{fh})'[f];"
          f"[0:v][f]overlay=(W-w)/2:(H-h)/2,fade=t=in:st=0:d=0.3{fo},format=yuv420p[v]")
    sh(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-framerate", str(FPS), "-t", f"{d + 0.2:.3f}", "-i", bgp, "-loop", "1", "-framerate", str(FPS), "-t", f"{d + 0.2:.3f}", "-i", regp,
        "-filter_complex", fc, "-map", "[v]", "-frames:v", str(int(round(d * FPS)))] + ENC + [path])
def seg_vid(path, d, clip, ss, crop=None, fadeout=0.0):
    if os.path.exists(path): return
    fo = f",fade=t=out:st={d - fadeout:.2f}:d={fadeout}" if fadeout else ""
    pre = (crop + ",") if crop else ""
    fc = (f"[0:v]{pre}split[a][b];[a]scale=160:90:force_original_aspect_ratio=increase,crop=160:90,boxblur=3:1,scale={W}:{H},eq=brightness=-0.15[bg];"
          f"[b]scale={W}:{H}:force_original_aspect_ratio=decrease:flags=lanczos,unsharp=5:5:0.5[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,tpad=stop_mode=clone:stop_duration=4,fade=t=in:st=0:d=0.2{fo},format=yuv420p[v]")
    sh(["ffmpeg", "-v", "error", "-y", "-ss", f"{ss:.2f}", "-t", f"{d + 0.5:.3f}", "-i", CL[clip], "-filter_complex", fc, "-map", "[v]", "-frames:v", str(int(round(d * FPS)))] + ENC + [path])

CUR = {}   # pool -> [segment index, position]
def take(pool, d):
    clip0, cls, lab, segs_ = story.POOLS[pool]
    cur = CUR.setdefault(pool, [0, segs_[0][0]])
    while True:
        if cur[0] >= len(segs_): raise SystemExit(f"POOL EXHAUSTED {pool} need {d:.2f}")
        a, b = segs_[cur[0]][:2]; clip = segs_[cur[0]][2] if len(segs_[cur[0]]) > 2 else clip0
        if cur[1] < a: cur[1] = a
        if b - cur[1] >= d - 0.01:
            ss = cur[1]; cur[1] += d + 0.3; return clip, ss, cls, lab
        cur[0] += 1
        if cur[0] < len(segs_): cur[1] = segs_[cur[0]][0]

def segs():
    ev = json.load(open("plan.json"))["events"]
    names = []; tot = dict(real=0.0, film=0.0, still=0.0, cards=0.0); log = []; labs = []
    lastline = [e for e in ev if e["k"] == "line"][-1]["id"]
    for n, e in enumerate(ev):
        d = (round(e["e"] * FPS) - round(e["s"] * FPS)) / FPS; base = f"seg/{n:03d}"
        if e["k"] == "card":
            png = f"seg/c{n:03d}.png"
            if e["kind"] == "open": cards.opening(png, TITLE, PLACE)
            else: cards.chapter(png, e["ch"], CHAP[e["ch"]])
            seg_card(base + ".mp4", d, png); names.append(base + ".mp4"); tot["cards"] += d; continue
        if e["k"] == "close2":
            png2 = f"seg/c{n:03d}.png"; cards.closing2(png2, PUNCH, QUEST, REFLIST, NOTE)
            seg_card(base + ".mp4", d, png2, 1.0, 1.2); names.append(base + ".mp4"); tot["cards"] += d; continue
        items = story.BEATS[e["id"]] if e["k"] == "beat" else story.M[e["id"]]
        wts = [it[4] if it[0] == "p" else it[2] for it in items]; tw = sum(wts); cum = 0.0
        bnd = [round(e["s"] * FPS)]
        for w_ in wts: cum += w_; bnd.append(round((e["s"] + d * cum / tw) * FPS))
        for k, it in enumerate(items):
            each = (bnd[k + 1] - bnd[k]) / FPS; pp = f"{base}_{k}.mp4"; ts0 = bnd[k] / FPS
            fo = 0.8 if (e["k"] == "line" and e["id"] == lastline and k == len(items) - 1) else 0.0
            if it[0] == "p":
                seg_pan(pp, each, f"{n:03d}_{k}", it, fo); tot["still"] += each; log.append((e["id"], it[1], "page", round(each, 2), "still", it[5])); labs.append((it[5], ts0, ts0 + each, "real"))
            else:
                clip, ss, cls, lab = take(it[1], each)
                seg_vid(pp, each, clip, ss, story.CROP[clip], fo); tot[cls] += each; log.append((e["id"], clip, round(ss, 2), round(each, 2), cls, it[1])); labs.append((lab, ts0, ts0 + each, cls))
            names.append(pp)
        print("seg", e["id"], round(d, 1), flush=True)
    json.dump(dict(names=names, tot=tot, log=log, labs=labs), open("segs.json", "w"), indent=0)
    T = sum(tot.values())
    print({k: round(v, 1) for k, v in tot.items()}, "total", round(T, 1), "real %.1f%% film %.1f%% still %.1f%% cards %.1f%%" % tuple(100 * tot[k] / T for k in ("real", "film", "still", "cards")))

def concat():
    names = json.load(open("segs.json"))["names"]
    open("concat.txt", "w").write("".join(f"file '{os.path.abspath(s)}'\n" for s in names)); print("concat list written")
def rd(p):
    w = wave.open(p); x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768; w.close(); return x
def audio():
    P = json.load(open("plan.json")); ev = P["events"]; TOTAL = P["total"]; SR = 44100; N = int(TOTAL * SR) + SR
    vo = np.zeros(N, dtype=np.float32)
    def norm(src, out, I):
        sh(["ffmpeg", "-v", "error", "-y", "-i", src, "-af", f"aresample={SR},aformat=channel_layouts=mono,loudnorm=I={I}:TP=-1.5:LRA=7", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_s16le", out])
    def lin_norm(src, out, I=-17.0):
        r = subprocess.run(LOCK + ["ffmpeg", "-v", "info", "-i", src, "-af", f"aresample={SR},aformat=channel_layouts=mono,loudnorm=I={I}:TP=-1.5:LRA=7:print_format=json", "-f", "null", "-"], capture_output=True, text=True).stderr
        j = json.loads(r[r.rindex("{"):r.rindex("}") + 1])
        af = (f"aresample={SR},aformat=channel_layouts=mono,loudnorm=I={I}:TP=-1.5:LRA=7:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
        sh(["ffmpeg", "-v", "error", "-y", "-i", src, "-af", af, "-ar", str(SR), "-ac", "1", "-c:a", "pcm_s16le", out])
    for e in ev:
        if e["k"] == "line":
            lin_norm(f"voice/{e['id']}.wav", "tmp_n.wav", -17)   # one constant gain per line, no decay
            x = rd("tmp_n.wav"); o = int(e["s"] * SR); vo[o:o + len(x)] += x[:N - o]
    sh(["ffmpeg", "-v", "error", "-y", "-i", "mus/bed.wav", "-af", f"aresample={SR},aformat=channel_layouts=mono,atrim=0:{TOTAL:.2f},afade=t=in:d=0.5,afade=t=out:st={TOTAL - 4.5:.2f}:d=4.5", "-ac", "1", "-c:a", "pcm_s16le", "bed.wav"])
    bed = rd("bed.wav") * 10 ** (float(os.environ.get("BEDDB", "0")) / 20)
    assert len(bed) >= int(TOTAL * SR) - 10, ("BED SHORTER THAN VIDEO", len(bed) / SR, TOTAL)
    mix = vo[:len(bed)].copy(); mix += bed
    mix = np.clip(mix, -1, 1); mixi = (mix * 32767).astype(np.int16)
    for name, arr in (("mix.wav", mixi), ("narr.wav", (np.clip(vo[:len(bed)], -1, 1) * 32767).astype(np.int16))):
        w = wave.open(name, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(arr.tobytes()); w.close()
    os.remove("tmp_n.wav"); os.remove("bed.wav"); print("audio ok", TOTAL)
def sts(x): return f"{int(x // 3600):02d}:{int(x % 3600 // 60):02d}:{int(x % 60):02d},{int(round((x % 1) * 1000)) % 1000:03d}"
def ts(x): return f"{int(x // 3600)}:{int(x % 3600 // 60):02d}:{x % 60:05.2f}"
def caps():
    sys.path.insert(0, '/home/claude/production-house/channels/laks-true-story/tools')
    import lts_sync as LS
    from PIL import ImageFont
    LS._F = ImageFont.truetype(LS.FONT_PATH, 76); LS.MAXW = 1500
    P = json.load(open("plan.json")); ev = P["events"]; CS = json.load(open("capsync.json")); wt = []
    allsent = []
    for e in ev:
        if e["k"] == "line": allsent.append((e["id"], [(t[0], e["s"] + t[1], e["s"] + t[2]) for t in CS[e["id"]]["tokens"]]))
    sents = []
    for lid, toks in allsent:
        cur = []
        for t in toks:
            cur.append(t)
            if re.search(r'[.!?]["]?$', t[0]): sents.append(cur); cur = []
        if cur: sents.append(cur)
    evs = LS.units_for(sents)
    for k, s in enumerate(sents):
        for t in s: wt.append([k, t[0], round(t[1], 3), round(t[2], 3)])
    json.dump(wt, open("word_times.json", "w"))
    srt = []; n = 0
    for a, b, lines in sorted(evs, key=lambda x: x[0]):
        n += 1; srt.append(f"{n}\n{sts(a)} --> {sts(b)}\n" + "\n".join(lines) + "\n")
    open("caps.srt", "w").write("\n".join(srt))
    hdr = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 2", "", "[V4+ Styles]",
           "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
           "Style: Lab,Poppins,32,&H00E6E6E6,&H0000FFFF,&H00000000,&H90000000,0,0,0,0,100,100,0,0,1,3,1,7,48,48,40,1",
           "Style: Film,Poppins,36,&H0000E6FF,&H0000FFFF,&H00000000,&HC0000000,1,0,0,0,100,100,0,0,3,10,0,7,40,40,36,1", "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"]
    out = list(hdr); labs = json.load(open("segs.json")).get("labs", []); runs = []
    for lb, a, b, cls in labs:
        if runs and runs[-1][0] == lb and a - runs[-1][2] < 0.3: runs[-1][2] = b
        else: runs.append([lb, a, b, cls])
    for lb, a, b, cls in runs:
        if b - a > 0.8: out.append(f"Dialogue: 1,{ts(a + 0.15)},{ts(b - 0.1)},{'Film' if cls == 'film' else 'Lab'},,0,0,0,," + lb)
    open("labels.ass", "w").write("\n".join(out) + "\n"); print("caption units (srt only)", n, "labels", len(out) - len(hdr))
def final():
    P = json.load(open("plan.json")); TOTAL = P["total"]
    def enc(outp, small):
        sc = ",scale=1280:720" if small else ""
        fc = f"[0:v]ass=labels.ass:fontsdir=/usr/share/fonts/truetype/google-fonts{sc}[v]"
        br = ["-b:v", "560k", "-maxrate", "720k", "-bufsize", "1500k"] if small else ["-b:v", os.environ.get("VBR", "1350k"), "-maxrate", "1800k", "-bufsize", "3600k"]
        sh(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "concat.txt", "-i", "mix.wav", "-filter_complex", fc, "-map", "[v]", "-map", "1:a", "-t", f"{TOTAL:.2f}",
            "-c:v", "libx264", "-preset", "veryfast"] + br + ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-movflags", "+faststart", outp])
    enc("master_1080p.mp4", False); print("master done")
    if not os.environ.get("ONLY1080"): enc("review_720p.mp4", True); print("720 done")
if __name__ == "__main__":
    {"plan": plan, "segs": segs, "concat": concat, "audio": audio, "caps": caps, "final": final}[STAGE]()
