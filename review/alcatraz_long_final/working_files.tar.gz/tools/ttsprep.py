import re,sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ttsprep_base as _b
_b.TIMES={}
_b.RESP=[]
RESP=[("Anglin","Ang-lin"),("Cronkhite","Kron-kite"),("Dollison","Doll-ih-son"),("Blackwell","Black-well")]
SPELL=[("FBI","F B I"),("US Marshals","U S Marshals"),("DNA","D N A"),("IQ","I Q"),("CBS","C B S"),("AP photo","A P photo"),("The AP","The A P"),("the AP","the A P")]
def tts(t):
    for a,b in SPELL: t=t.replace(a,b)
    for a,b in RESP: t=t.replace(a,b)
    return _b.tts(t)
if __name__=="__main__":
    exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),"lines.py")).read())
    for i,c,tx in L: print(i,"|",tts(tx))
