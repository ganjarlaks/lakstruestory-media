import sys,os,re,json,time
import torch, torchaudio as ta
_o=torch.load; torch.load=lambda *a,**k:_o(*a,**{**k,"map_location":torch.device("cpu")})
from chatterbox.tts import ChatterboxTTS
torch.set_num_threads(2)
MONTH=r"(January|February|March|April|May|June|July|August|September|October|November|December)"
ORD={1:"first",2:"second",4:"fourth",6:"sixth",10:"tenth",11:"eleventh",16:"sixteenth",28:"twenty-eighth",30:"thirtieth"}
YR={"1962":"nineteen sixty-two","1963":"nineteen sixty-three","1964":"nineteen sixty-four","1965":"nineteen sixty-five","1968":"nineteen sixty-eight","1975":"nineteen seventy-five","1976":"nineteen seventy-six","2013":"twenty thirteen"}
def tts_text(t):
    t=re.sub(r"\b(\d{1,2}) "+MONTH,lambda m:f"the {ORD[int(m.group(1))]} of {m.group(2)}",t)
    for k,v in YR.items(): t=t.replace(k,v)
    for a,b in [("sixty seven","sixty-seven"),(" 39."," thirty-nine."),("John F. Kennedy","John F Kennedy"),("J. Edgar","J Edgar"),("Clarence B. Jones","Clarence B Jones"),("History.com","History dot com"),("FBI","F B I"),("A. Philip","A Philip")]: t=t.replace(a,b)
    return t
def load():
    m=ChatterboxTTS.from_pretrained(device="cpu")
    tf=m.t3.tfmr; tf.to(torch.bfloat16)
    tf.register_forward_pre_hook(lambda mod,a,k:(a,{**k,"inputs_embeds":k["inputs_embeds"].to(torch.bfloat16)} if k.get("inputs_embeds") is not None else k),with_kwargs=True)
    def _post(mod,a,k,o):
        o.last_hidden_state=o.last_hidden_state.float()
        if getattr(o,'hidden_states',None) is not None: o.hidden_states=tuple(h.float() for h in o.hidden_states)
        return o
    tf.register_forward_hook(_post,with_kwargs=True)
    import gc,ctypes; gc.collect()
    try: ctypes.CDLL('libc.so.6').malloc_trim(0)
    except Exception: pass
    return m
if False:
    # usage: gen.py lines.json outdir ref [ids,comma]
    lines=json.load(open(sys.argv[1])); out=sys.argv[2]; ref=sys.argv[3]
    sel=sys.argv[4].split(",") if len(sys.argv)>4 else None
    os.makedirs(out,exist_ok=True)
    m=load()
    for i,w,t in lines:
        if sel and i not in sel: continue
        pf=f"{out}/{i}.wav"
        if os.path.exists(pf): continue
        ts=time.time()
        with torch.inference_mode(): wav=m.generate(t,audio_prompt_path=ref,exaggeration=0.3,cfg_weight=0.3)
        ta.save(pf+".tmp.wav",wav,m.sr); os.rename(pf+".tmp.wav",pf)
        print(i,w,"words",round(wav.shape[-1]/m.sr,2),"s audio",round(time.time()-ts),"s compute",flush=True)
    print("BATCHDONE",flush=True)
