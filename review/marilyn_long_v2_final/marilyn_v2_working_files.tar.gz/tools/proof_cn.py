# Caption-sync proof: python3 lts_proof.py VIDEO WORD_TIMES.json NARR_TRACK.wav OUTPREFIX [guideY]
# 1) independent Whisper base.en word times on the final narration track vs forced-alignment word times (diff stats)
# 2) frames at start / middle / end of 8 sentences with the caption on screen, on a contact sheet with the words being spoken at that instant
import sys,json,subprocess,re
sys.path.insert(0,'/home/claude/production-house/channels/laks-true-story/tools')
import lts_sync as L
from PIL import Image,ImageDraw,ImageFont
vid,wt,nar,out=sys.argv[1:5]; guide=int(sys.argv[5]) if len(sys.argv)>5 else None
W=json.load(open(wt))   # [sentence_idx, word, start, end]
from faster_whisper import WhisperModel
_m=WhisperModel('base.en',device='cpu',compute_type='int8',cpu_threads=1)
_segs,_=_m.transcribe(L.read16k(nar),language='en',word_timestamps=True,beam_size=2,condition_on_previous_text=False)
wh=[(w.word.strip(),w.start,w.end) for s_ in _segs for w in s_.words]
norm=lambda w:re.sub(r'[^a-z]','',w.lower())
# sequential matching of identical normalised words
diffs=[]
for si,w,a,b in W:
    n=norm(w)
    if not n: continue
    c=[x for x in wh if norm(x[0])==n and abs(float(x[1])-a)<1.5]
    if c:
        x=min(c,key=lambda x:abs(float(x[1])-a)); diffs.append((w,a,float(x[1]),abs(a-float(x[1]))))
import numpy as np
d=np.array([x[3] for x in diffs])
stat=f'matched {len(diffs)} of {len(W)} words; start-time difference forced-alignment vs Whisper: mean {d.mean():.3f} s, median {np.median(d):.3f} s, 90th pct {np.percentile(d,90):.3f} s, max {d.max():.3f} s (worst: {max(diffs,key=lambda x:x[3])[0]!r})'
print(stat); open(out+'_sync_stats.txt','w').write(stat+'\n')
S={}
for si,w,a,b in W: S.setdefault(si,[]).append((w,a,b))
sel=sorted(S)[:]; step=max(1,len(sel)//8); sel=sel[::step][:8]
FONT=ImageFont.truetype('/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf',18)
tw,th=480,270; rows=[]
for si in sel:
    ws=S[si]; t0,t1=ws[0][1],ws[-1][2]
    ts=[t0+0.12,(t0+t1)/2,t1-0.12]
    row=Image.new('RGB',(tw*3+20,th+70),(20,20,20)); d_=ImageDraw.Draw(row)
    for i,t in enumerate(ts):
        subprocess.run(f'ffmpeg -v error -y -ss {t:.3f} -i {vid} -frames:v 1 /dev/shm/_pf.png',shell=True,check=True)
        im=Image.open('/dev/shm/_pf.png').convert('RGB')
        if guide: ImageDraw.Draw(im).line((0,guide,1080,guide),fill=(255,0,0),width=3)
        im=im.resize((tw,th)); row.paste(im,(i*(tw+10),0))
        spoken=' '.join(w for w,a,b in ws if a<=t<=b+0.02) or '(between words)'
        d_.text((i*(tw+10),th+4),f't={t:.2f}s',font=FONT,fill=(255,214,10))
        d_.text((i*(tw+10),th+28),('says: '+spoken)[:52],font=FONT,fill=(255,255,255))
    rows.append(row)
sheet=Image.new('RGB',(rows[0].width*2+10,sum(r.height for r in rows[::2])+10),(0,0,0))
for i,r in enumerate(rows): sheet.paste(r,((i%2)*(r.width+10),(i//2)*r.height))
sheet.save(out+'_sync_proof.jpg',quality=85); print('sheet',sheet.size,[S[s][0][0] for s in sel])
