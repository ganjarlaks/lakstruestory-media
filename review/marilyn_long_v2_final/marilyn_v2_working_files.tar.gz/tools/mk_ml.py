#!/usr/bin/env python3
"""LTS Marilyn Monroe long builder (four-chapter semi-biography). Adapted from the Saddam builder (build_tm.py).
usage: mk_ml.py WORK stage   stages: plan | segs | concat | audio | caps | final
OWNER RULE 10 Nov 2026: NO burned-in narration captions. Master has only the small top-left source labels (no foreign-language speech in this video, so no burned subtitles).
Every ffmpeg runs under flock /tmp/render.lock nice -n 19."""
import json, os, re, subprocess, sys, wave, textwrap
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lines import L
import story, cards
from PIL import Image, ImageFilter, ImageEnhance
Image.MAX_IMAGE_PIXELS = None
W, H, FPS = 1920, 1080, 25
WORK = sys.argv[1]; STAGE = sys.argv[2]
os.chdir(WORK); os.makedirs("seg", exist_ok=True)
GAP = float(os.environ.get("GAP", "1.2")); CARD = 5.0
TITLE = os.environ.get("MTITLE", "Marilyn Monroe : Her Voice and the Three Days After")
PLACE = "Los Angeles · 1962"
CHAP = {"1": "Norma Jeane Became Marilyn", "2": "The Films", "3": "The Last Year", "4": "The Three Days After"}
txt = {i: t for i, c, t, *_ in L}
PUNCH = txt["Z1"]; QUEST = txt["Z2"]
REFLIST = ["Evening Star, Washington, 6 and 8 Aug 1962 (Library of Congress)", "The Legend of Marilyn Monroe, 1966 documentary (archive.org)", "The Jack Benny Program, 13 Sep 1953; Edgar Bergen radio show, Nov 1952", "The Big Picture, US Army, Korea 1954; studio trailers 1953 to 1959", "Funeral programme, 8 Aug 1962 (California Revealed)", "Fox News interview with Lawrence Schiller, 2012; LA County DA review, 1982"]
NOTE = "Full list with links in the description"
LOCK = ["flock", "/tmp/render.lock", "nice", "-n", "19"]
RA = story.RA; RA_AFTER = {}
for k, v in RA.items(): RA_AFTER.setdefault(v["after"], []).append(k)
CL = {"lgA":"src/lgA.mp4","lgB":"src/lgB.mp4","lgC":"src/lgC.mp4","lgD":"src/lgD.mp4","lgE":"src/lgE.mp4","lgF":"src/lgF.mp4","lgG":"src/lgG.mp4","lgH":"src/lgH.mp4","lgI":"src/lgI.mp4","lgJ":"src/lgJ.mp4","lgK":"src/lgK.mp4","lgM":"src/lgM.mp4","tN":"src/t_niagara.mp4","tG":"src/t_gpb.mp4","tH":"src/t_htm.mp4","tR":"src/t_river.mp4","tI":"src/t_itch.mp4","tB":"src/t_busstop.mp4","tS":"src/t_slih.mp4","sk": "src/benny_sk.mp4", "iv": "src/benny_iv.mp4", "ko": "src/bigpic_k.mp4", "hb": "src/hb.mp4", "st": "src/st.mp4"}
ENC = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p", "-r", str(FPS), "-an"]
def sh(cmd): subprocess.run(LOCK + cmd, check=True)
def wdur(i):
    w = wave.open(f"voice/{i}.wav"); d = w.getnframes() / w.getframerate(); w.close(); return d

def plan():
    ev = []; t = 0.0
    def add(k, d, **kw):
        nonlocal t; ev.append(dict(k=k, s=round(t, 3), e=round(t + d, 3), **kw)); t += d
    for typ, key in story.SEQ:
        if typ == "card":
            if key == "open": add("card", CARD, kind="open")
            elif key == "close": add("close2", CARD)
            else: add("card", CARD, kind="chap", ch=key)
        elif typ == "line":
            vd = wdur(key); add("line", vd + GAP, id=key, vd=vd)
        elif typ == "ra":
            r = RA[key]; add("ra", r["dur"] + 0.5, id=key, vd=r["dur"])
        elif typ == "beat":
            d = sum(it[3] for it in story.BEATS[key]["items"]); add("beat", d, id=key)
    json.dump(dict(events=ev, total=t), open("plan.json", "w"), indent=1)
    print("TOTAL %.1f s = %d:%05.2f" % (t, t // 60, t % 60)); return ev, t

_IMG = {}
def page(pg):
    if pg not in _IMG:
        f, aw = story.PAGES[pg]; im = Image.open(f).convert("L"); s = (im.width / aw) if aw else 1.0
        _IMG[pg] = (im, s)
    return _IMG[pg]

def seg_card(path, d, png, fi=0.5, fo=0.5):
    if os.path.exists(path): return
    vf = f"fade=t=in:st=0:d={fi},fade=t=out:st={max(d - fo, 0.1):.2f}:d={fo},format=yuv420p"
    sh(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-framerate", str(FPS), "-i", png, "-t", f"{d + 0.5:.3f}", "-frames:v", str(int(round(d * FPS))), "-vf", vf] + ENC + [path])

def seg_pan(path, d, key, it, fadeout=0.0):
    if os.path.exists(path): return
    _, pg, win, end, wgt, lab = it
    im, s = page(pg); x, y, w, h = win; x2, y2 = end if end else (x, y)
    rx0, ry0 = min(x, x2), min(y, y2); rx1, ry1 = max(x, x2) + w, max(y, y2) + h
    f = min(1700 / (w * s), 960 / (h * s))
    reg = im.crop((int(rx0 * s), int(ry0 * s), int(rx1 * s), int(ry1 * s))).convert("RGB")
    reg = reg.resize((max(2, int(reg.width * f)), max(2, int(reg.height * f))), Image.LANCZOS)
    reg = ImageEnhance.Contrast(reg).enhance(1.08); regp = f"seg/r_{key}.png"; reg.save(regp)
    fw = min(int(w * s * f), reg.width - 2) // 2 * 2; fh = min(int(h * s * f), reg.height - 2) // 2 * 2
    xs, ys = (x - rx0) * s * f, (y - ry0) * s * f; xe, ye = (x2 - rx0) * s * f, (y2 - ry0) * s * f
    wc = im.crop((int(x * s), int(y * s), int((x + w) * s), int((y + h) * s))).convert("RGB").resize((W, H)).filter(ImageFilter.GaussianBlur(28))
    wc = ImageEnhance.Brightness(wc).enhance(0.42); bgp = f"seg/b_{key}.png"; wc.save(bgp)
    fo = f",fade=t=out:st={d - fadeout:.2f}:d={fadeout}" if fadeout else ""
    fc = (f"[1:v]crop={fw}:{fh}:x='min({xs:.1f}+({xe:.1f}-{xs:.1f})*t/{d:.3f},iw-{fw})':y='min({ys:.1f}+({ye:.1f}-{ys:.1f})*t/{d:.3f},ih-{fh})'[f];"
          f"[0:v][f]overlay=(W-w)/2:(H-h)/2,fade=t=in:st=0:d=0.3{fo},format=yuv420p[v]")
    sh(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-framerate", str(FPS), "-t", f"{d + 0.2:.3f}", "-i", bgp, "-loop", "1", "-framerate", str(FPS), "-t", f"{d + 0.2:.3f}", "-i", regp,
        "-filter_complex", fc, "-map", "[v]", "-frames:v", str(int(round(d * FPS)))] + ENC + [path])

def seg_vid(path, d, clip, ss, crop=None, fadeout=0.0):
    if os.path.exists(path): return
    fo = f",fade=t=out:st={d - fadeout:.2f}:d={fadeout}" if fadeout else ""
    pre = (crop + ",") if crop else ""
    fc = (f"[0:v]{pre}split[a][b];[a]scale=160:90:force_original_aspect_ratio=increase,crop=160:90,boxblur=3:1,scale={W}:{H},eq=brightness=-0.15[bg];"
          f"[b]scale={W}:{H}:force_original_aspect_ratio=decrease:flags=lanczos,unsharp=5:5:0.5[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,tpad=stop_mode=clone:stop_duration=4,fade=t=in:st=0:d=0.2{fo},format=yuv420p[v]")
    sh(["ffmpeg", "-v", "error", "-y", "-ss", f"{ss:.2f}", "-t", f"{d + 0.5:.3f}", "-i", CL[clip], "-filter_complex", fc, "-map", "[v]", "-frames:v", str(int(round(d * FPS)))] + ENC + [path])

def segs():
    ev = json.load(open("plan.json"))["events"]
    names = []; moving = 0.0; still = 0.0; cards_t = 0.0; log = []; labs = []; pieces = []
    lastline = [e for e in ev if e["k"] == "line"][-1]["id"]
    for n, e in enumerate(ev):
        d = (round(e["e"] * FPS) - round(e["s"] * FPS)) / FPS; base = f"seg/{n:03d}"
        if e["k"] == "card":
            png = f"seg/c{n:03d}.png"
            if e["kind"] == "open": cards.opening(png, TITLE, PLACE)
            else: cards.chapter(png, e["ch"], CHAP[e["ch"]])
            seg_card(base + ".mp4", d, png); names.append(base + ".mp4"); cards_t += d; continue
        if e["k"] == "close2":
            png2 = f"seg/c{n:03d}.png"; cards.closing2(png2, PUNCH, QUEST, REFLIST, NOTE)
            seg_card(base + ".mp4", d, png2, 1.0, 1.2); names.append(base + ".mp4"); cards_t += d; continue
        if e["k"] == "ra":
            r = RA[e["id"]]; clip, pss = r["pic"]
            seg_vid(base + ".mp4", d, clip, pss, None); names.append(base + ".mp4"); moving += d
            log.append((e["id"], clip, pss, round(d, 2), "direct (her own voice)" if e["id"] != "RA4" else "witness audio over context picture")); labs.append((r["label"], e["s"], e["s"] + d)); continue
        if e["k"] == "beat":
            t0 = e["s"]
            for k, it in enumerate(story.BEATS[e["id"]]["items"]):
                dd = (round((t0 + it[3]) * FPS) - round(t0 * FPS)) / FPS; pp = f"{base}_{k}.mp4"
                seg_vid(pp, dd, it[1], it[2], it[5]); names.append(pp); moving += dd; labs.append((it[4], t0, t0 + dd)); log.append((e["id"], it[1], it[2], round(dd, 2), "context")); t0 += it[3]
            continue
        items = story.M[e["id"]]
        wts = [it[4] if it[0] == "p" else it[3] for it in items]; tw = sum(wts); cum = 0.0
        bnd = [round(e["s"] * FPS)]
        for w_ in wts: cum += w_; bnd.append(round((e["s"] + d * cum / tw) * FPS))
        for k, it in enumerate(items):
            each = (bnd[k + 1] - bnd[k]) / FPS; pp = f"{base}_{k}.mp4"; fo = 0.8 if (e["id"] == lastline and k == len(items) - 1) else 0.0
            ts0 = bnd[k] / FPS
            if it[0] == "p":
                seg_pan(pp, each, f"{n:03d}_{k}", it, fo); still += each; log.append((e["id"], it[1], "page", round(each, 2), "document")); labs.append((it[5], ts0, ts0 + each))
            else:
                seg_vid(pp, each, it[1], it[2], it[5], fo); (still if False else None); st_ = (len(it) > 6 and it[6]); moving += 0 if st_ else each; still += each if st_ else 0; log.append((e["id"], it[1], it[2], round(each, 2), "still (filmed headline)" if st_ else "context")); labs.append((it[4], ts0, ts0 + each))
            names.append(pp)
        print("seg", e["id"], round(d, 1), flush=True)
    json.dump(dict(names=names, moving=moving, still=still, cards=cards_t, log=log, labs=labs), open("segs.json", "w"), indent=0)
    tot = moving + still + cards_t
    print("MOVING %.1f s, STILL %.1f s, CARDS %.1f s => %.1f%% moving of runtime, %.1f%% of picture time (no cards)" % (moving, still, cards_t, 100 * moving / tot, 100 * moving / (moving + still)))

def concat():
    names = json.load(open("segs.json"))["names"]
    open("concat.txt", "w").write("".join(f"file '{os.path.abspath(s)}'\n" for s in names)); print("concat list written")

def rd(p):
    w = wave.open(p); x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768; w.close(); return x

def audio():
    P = json.load(open("plan.json")); ev = P["events"]; TOTAL = P["total"]; SR = 44100; N = int(TOTAL * SR) + SR
    vo = np.zeros(N, dtype=np.float32)
    def norm(src, out, I, extra=()):
        sh(["ffmpeg", "-v", "error", "-y"] + list(extra) + ["-i", src, "-af", f"aresample={SR},aformat=channel_layouts=mono,loudnorm=I={I}:TP=-1.5:LRA=7", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_s16le", out])
    def lin_norm(src, out, I=-16.0):
        r = subprocess.run(LOCK + ["ffmpeg", "-v", "info", "-i", src, "-af", f"aresample={SR},aformat=channel_layouts=mono,loudnorm=I={I}:TP=-1.5:LRA=7:print_format=json", "-f", "null", "-"], capture_output=True, text=True).stderr
        j = json.loads(r[r.rindex("{"):r.rindex("}") + 1])
        af = (f"aresample={SR},aformat=channel_layouts=mono,loudnorm=I={I}:TP=-1.5:LRA=7:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
        sh(["ffmpeg", "-v", "error", "-y", "-i", src, "-af", af, "-ar", str(SR), "-ac", "1", "-c:a", "pcm_s16le", out])
    AUDSRC = {"mc": "src/mccarthy.mp3", "iv": "src/benny_iv.mp4", "hb": "src/hb.mp4", "schiller": "src/schiller_aud.wav"}
    for e in ev:
        if e["k"] == "line":
            if e["id"] in ("Z1", "Z2"): lin_norm(f"voice/{e['id']}.wav", "tmp_n.wav", -16)   # closing lines: ONE constant gain, no decay
            else: norm(f"voice/{e['id']}.wav", "tmp_n.wav", -16)
            x = rd("tmp_n.wav"); o = int(e["s"] * SR); vo[o:o + len(x)] += x[:N - o]
        if e["k"] == "ra":
            r = RA[e["id"]]
            # fade 25 ms at both edges, constant gain (one loudnorm pass per clip)
            sh(["ffmpeg", "-v", "error", "-y", "-ss", f"{r['ss']:.2f}", "-t", f"{r['dur']:.2f}", "-i", AUDSRC[r["aud"]], "-af", f"aresample={SR},aformat=channel_layouts=mono,afade=t=in:d=0.025,afade=t=out:st={r['dur'] - 0.025:.3f}:d=0.025,loudnorm=I=-17:TP=-1.5:LRA=9", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_s16le", "tmp_n.wav"])
            x = rd("tmp_n.wav"); o = int(e["s"] * SR); vo[o:o + len(x)] += x[:N - o]
    sh(["ffmpeg", "-v", "error", "-y", "-i", "mus/bed.wav", "-af", f"aresample={SR},aformat=channel_layouts=mono,atrim=0:{TOTAL:.2f},afade=t=in:d=0.5,afade=t=out:st={TOTAL - 4.5:.2f}:d=4.5", "-ac", "1", "-c:a", "pcm_s16le", "bed.wav"])
    bed = rd("bed.wav") * 10 ** (-3.3 / 20)
    g = np.ones(len(bed), dtype=np.float32)
    for e in ev:
        if e["k"] == "ra":
            a = int(e["s"] * SR); b = int((e["s"] + e["vd"]) * SR); rp = int(0.4 * SR)
            g[a:b] = 0.0
            g[max(a - rp, 0):a] = np.minimum(g[max(a - rp, 0):a], np.linspace(1, 0, a - max(a - rp, 0)))
            g[b:b + rp] = np.minimum(g[b:b + rp], np.linspace(0, 1, len(g[b:b + rp])))
    mix = vo[:len(bed)].copy(); mix += bed * g
    mix = np.clip(mix, -1, 1); mixi = (mix * 32767).astype(np.int16)
    for name, arr in (("mix.wav", mixi), ("narr.wav", (np.clip(vo[:len(bed)], -1, 1) * 32767).astype(np.int16))):
        w = wave.open(name, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(arr.tobytes()); w.close()
    os.remove("tmp_n.wav"); os.remove("bed.wav"); print("audio ok", TOTAL)

def sts(x): return f"{int(x // 3600):02d}:{int(x % 3600 // 60):02d}:{int(x % 60):02d},{int(round((x % 1) * 1000)) % 1000:03d}"
def ts(x): return f"{int(x // 3600)}:{int(x % 3600 // 60):02d}:{x % 60:05.2f}"

def caps():
    """Writes: caps.srt + word_times.json (separate files, NOT burned in) and labels.ass (small top-left source labels only, burned in)."""
    sys.path.insert(0, '/home/claude/production-house/channels/laks-true-story/tools')
    import lts_sync as LS
    from PIL import ImageFont
    LS._F = ImageFont.truetype(LS.FONT_PATH, 76); LS.MAXW = 1500
    P = json.load(open("plan.json")); ev = P["events"]; CS = json.load(open("capsync.json")); wt = []
    allsent = []
    for e in ev:
        if e["k"] == "line": allsent.append((e["id"], [(t[0], e["s"] + t[1], e["s"] + t[2]) for t in CS[e["id"]]["tokens"]]))
    sents = []
    for lid, toks in allsent:
        cur = []
        for t in toks:
            cur.append(t)
            if re.search(r"[.!?]$", t[0]): sents.append(cur); cur = []
        if cur: sents.append(cur)
    evs = LS.units_for(sents)
    for k, s in enumerate(sents):
        for t in s: wt.append([k, t[0], round(t[1], 3), round(t[2], 3)])
    json.dump(wt, open("word_times.json", "w"))
    srt = []; n = 0
    for a, b, lines in sorted(evs, key=lambda x: x[0]):
        n += 1; srt.append(f"{n}\n{sts(a)} --> {sts(b)}\n" + "\n".join(lines) + "\n")
    open("caps.srt", "w").write("\n".join(srt))
    hdr = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 2", "", "[V4+ Styles]",
           "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
           "Style: Lab,Poppins,34,&H00E6E6E6,&H0000FFFF,&H00000000,&H90000000,0,0,0,0,100,100,0,0,1,3,1,7,48,48,40,1", "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"]
    out = list(hdr)
    labs = json.load(open("segs.json")).get("labs", [])
    runs = []
    for lb, a, b in labs:
        if runs and runs[-1][0] == lb and a - runs[-1][2] < 0.3: runs[-1][2] = b
        else: runs.append([lb, a, b])
    for lb, a, b in [(lb, a + 0.3, min(b, a + 4.8)) for lb, a, b in runs if b - a > 1.2]: out.append(f"Dialogue: 1,{ts(a)},{ts(b)},Lab,,0,0,0,," + lb)
    open("labels.ass", "w").write("\n".join(out) + "\n"); print("caption units (srt only)", n, "labels", len(out) - len(hdr))

def final():
    P = json.load(open("plan.json")); TOTAL = P["total"]
    def enc(outp, small):
        sc = ",scale=1280:720" if small else ""
        fc = f"[0:v]ass=labels.ass:fontsdir=/usr/share/fonts/truetype/google-fonts{sc}[v]"
        br = ["-b:v", "560k", "-maxrate", "720k", "-bufsize", "1500k"] if small else ["-b:v", "1350k", "-maxrate", "1800k", "-bufsize", "3600k"]
        sh(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "concat.txt", "-i", "mix.wav", "-filter_complex", fc, "-map", "[v]", "-map", "1:a", "-t", f"{TOTAL:.2f}",
            "-c:v", "libx264", "-preset", "veryfast"] + br + ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-movflags", "+faststart", outp])
    enc("master_1080p.mp4", False); print("master done")
    if not os.environ.get("ONLY1080"): enc("review_720p.mp4", True); print("720 done")

if __name__ == "__main__":
    {"plan": plan, "segs": segs, "concat": concat, "audio": audio, "caps": caps, "final": final}[STAGE]()
