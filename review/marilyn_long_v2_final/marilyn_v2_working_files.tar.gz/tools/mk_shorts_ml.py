#!/usr/bin/env python3
"""Marilyn Monroe long: Shorts A and B on the LOCKED v5 template (1080x1920, 30 fps, <= 30.0 s, 2.0 s open card, 3.0 s closing card,
constant-level closing voice vo_fraser_flat_closing.wav). Voice = the long's own narration track (narr.wav, per-line loudnorm; Z lines linear) cut at line/word
boundaries; nothing generated. Picture = archive.org clips (4:3 centre/side crop to 1080x1344) and Library of Congress newspaper pages (pan, blurred fill).
usage: mk_shorts_ml.py WORK A|B   (no outer flock: every ffmpeg call takes flock /tmp/render.lock itself)"""
import json, os, re, subprocess, sys, math
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
Image.MAX_IMAGE_PIXELS = None
WORK, WHICH = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(WORK, 'tools'))
import story
os.chdir(WORK); SD = os.path.join(WORK, 'shorts', WHICH); os.makedirs(SD, exist_ok=True)
FPS = 30; W, H = 1080, 1920
TITLE = os.environ.get("MTITLE", "Marilyn Monroe : Her Voice and the Three Days After"); PLACE = "Los Angeles · 1962"
SERIF = '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'; SANS = '/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf'; FD = '/usr/share/fonts/truetype/google-fonts'
AV = '/home/claude/lakstruestory-media/assets/shorts_v5/channel_avatar.jpg'; FLAT = os.path.join(WORK, 'shorts', 'vo_fraser_flat_closing.wav')
CRED = {'A': 'Source: archive.org, 1953 and 1962', 'B': 'Source: Evening Star, 1962 (Library of Congress); archive.org'}
P = json.load(open('plan.json'))['events']; PL = {e['id']: e for e in P if 'id' in e}
CS = json.load(open('capsync.json'))
def sh(c, quiet=True):
    r = subprocess.run(['flock', '/tmp/render.lock', 'nice', '-n', '19'] + c, capture_output=True, text=True)
    if r.returncode: print('FAIL', ' '.join(c)[:300], r.stderr[-600:]); sys.exit(1)
def ts(x): return f'{int(x // 3600)}:{int(x % 3600 // 60):02d}:{x % 60:05.2f}'
# ---------- plan.  unit = dict(src line id, a, b = cut inside the line wav (s), pics, caps = 'line' | text list)
# pic: ('v', clip, ss, dur, cropx)  |  ('p', page, win, end)  (durations split evenly over the unit)
RA1_TXT = None
UNITS = {
 'A': [dict(id='RA1', a=0.0, b=6.65, pics=[('v', 'iv', 8.95, 6.65, 150)], real=True),
       dict(id='3.3', a=0.2, b=10.3, pics=[('v', 'lgH', 22.0, 3.4, 250), ('v', 'lgH', 40.0, 3.3, 255), ('v', 'lgH', 62.0, 3.4, 250)]),
       dict(id='Z2', a=0.1, b=4.0, pics=[('v', 'iv', 52.0, 3.9, 150)])],
 'B': [dict(id='4.5', a=0.1, b=7.7, pics=[('p', 'A1', story.HEAD_A1, (3050, 3520)), ('v', 'lgJ', 3.0, 3.0, 120)]),
       dict(id='4.7', a=0.2, b=12.0, pics=[('v', 'lgJ', 0.0, 3.0, 120), ('v', 'lgJ', 6.0, 3.0, 120), ('v', 'lgJ', 45.0, 3.0, 100)]),
       dict(id='Z2', a=0.1, b=4.0, pics=[('v', 'lgA', 15.0, 3.9, 100)])]}
CL = {'iv': 'src/benny_iv.mp4', 'hb': 'src/hb.mp4', 'st': 'src/st.mp4', 'lgH': 'src/lgH.mp4', 'lgJ': 'src/lgJ.mp4', 'lgA': 'src/lgA.mp4'}
GAP = 0.3; LABS = {}
def words_for(u):
    """[(word, abs start, abs end)] relative to the unit audio start (cut a)."""
    if u['id'] == 'RA1':
        import json as j
        t = j.load(open(os.path.join(SD, 'ra1_words.json')))
        return [(w, s, e) for w, s, e in t]
    toks = CS[u['id']]['tokens']
    return [(t[0], t[1] - u['a'], t[2] - u['a']) for t in toks if t[1] is not None and t[1] >= u['a'] - 0.02 and t[2] <= u['b'] + 0.05]
def ra1_words():
    f = os.path.join(SD, 'ra1_words.json')
    if os.path.exists(f): return
    sys.path.insert(0, '/home/claude/production-house/channels/laks-true-story/tools')
    import lts_sync as L
    from faster_whisper import WhisperModel
    e = PL['RA1']; sh(['ffmpeg', '-v', 'error', '-y', '-ss', f"{e['s']:.3f}", '-t', f"{e['vd']:.3f}", '-i', 'narr.wav', '-ar', '16000', '-ac', '1', os.path.join(SD, 'ra1.wav')])
    wm = WhisperModel('base.en', device='cpu', compute_type='int8', cpu_threads=2)
    segs, _ = wm.transcribe(L.read16k(os.path.join(SD, 'ra1.wav')), word_timestamps=True, language='en', beam_size=5, condition_on_previous_text=False)
    w = [(x.word.strip(), x.start, x.end) for s in segs for x in s.words]
    print('RA1 words:', w); json.dump(w, open(f, 'w'))
def chunks(ws, maxc=26):
    """greedy chunks of at most 2 lines (<= maxc chars per line)."""
    out = []; cur = []
    for w in ws:
        cand = cur + [w]; txt = ' '.join(x[0] for x in cand)
        if cur and (len(txt) > maxc * 2 - 4 or re.search(r'[.?!]$', cur[-1][0])): out.append(cur); cur = [w]
        else: cur = cand
    if cur: out.append(cur)
    return out
def two(x):
    w = x.split()
    if len(x) <= maxc_line: return x
    best = None
    for i in range(1, len(w)):
        a = ' '.join(w[:i]); b = ' '.join(w[i:]); sc = max(len(a), len(b))
        if best is None or sc < best[0]: best = (sc, a, b)
    return best[1] + '\\N' + best[2]
maxc_line = 27
HEAD = '''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Cap,Poppins,95.3,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,8,90,90,1380,1
Style: Cred,Poppins,53,&H00C0C0C0,&H00C0C0C0,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,8,90,90,1600,1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
def wrap(d, t, font, mw):
    L = []; c = ''
    for w in t.split():
        x = (c + ' ' + w).strip()
        if d.textlength(x, font=font) <= mw: c = x
        else: L.append(c); c = w
    L.append(c); return L
def center(d, t, font, y, fill):
    w = d.textlength(t, font=font); d.text(((W - w) / 2, y), t, font=font, fill=fill)
def make_cards():
    tl = TITLE.split(' : ', 1); tl = [tl[0] + ' :', tl[1]] if len(tl) == 2 else [TITLE]
    im = Image.new('RGB', (W, H), 0); d = ImageDraw.Draw(im); tf = ImageFont.truetype(SERIF, 88)
    L = []
    for l in tl: L += wrap(d, l, tf, 940)
    shift = (3 - len(L)) * 52
    center(d, 'A TRUE STORY', ImageFont.truetype(SANS, 40), 632 + shift, (192, 192, 192)); y = 750 + shift
    for l in L: center(d, l, tf, y, (255, 255, 255)); y += 88 + 16
    d.rectangle(((W - 160) / 2, y + 34, (W + 160) / 2, y + 42), fill=(255, 210, 0)); center(d, PLACE, ImageFont.truetype(SANS, 40), y + 98, (192, 192, 192)); im.save(SD + '/open.png')
    im = Image.new('RGB', (W, H), 0); d = ImageDraw.Draw(im); tf = ImageFont.truetype(SERIF, 84); y = 420
    L = []
    for l in tl: L += wrap(d, l, tf, 940)
    for l in L: center(d, l, tf, y, (255, 255, 255)); y += 84 + 16
    d.rectangle(((W - 160) / 2, y + 34, (W + 160) / 2, y + 42), fill=(255, 210, 0))
    av = Image.open(AV).convert('RGB').resize((260, 260)); m = Image.new('L', (260, 260), 0); ImageDraw.Draw(m).ellipse((0, 0, 259, 259), fill=255)
    im.paste(av, (410, 1130), m); center(d, 'Full video at our channel', ImageFont.truetype(SERIF, 60), 1430, (255, 255, 255)); im.save(SD + '/close.png')
ENC = ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '-r', str(FPS), '-an']
def pic_video(p, d, out):
    nf = int(round(d * FPS))
    if p[0] == 'v':
        _, clip, ss, _, cx = p
        wh = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', CL[clip]], capture_output=True, text=True).stdout.strip().split(',')
        iw, ih = int(wh[0]), int(wh[1]); cw = int(ih * 1080 / 1344) // 2 * 2; cx = max(0, min(cx, iw - cw))
        sh(['ffmpeg', '-v', 'error', '-y', '-ss', f'{ss:.2f}', '-t', f'{d + 0.5:.3f}', '-i', CL[clip], '-vf', f'crop={cw}:{ih}:{cx}:0,scale=1080:1344:flags=lanczos,unsharp=5:5:0.6,fps={FPS},format=yuv420p', '-frames:v', str(nf)] + ENC + [out])
    else:
        _, pg, win, end = p
        f, aw = story.PAGES[pg]; im = Image.open(f).convert('L'); s = im.width / aw
        x, y, w, h = win; x2, y2 = end
        rx0, ry0 = min(x, x2), min(y, y2); rx1, ry1 = max(x, x2) + w, max(y, y2) + h
        fct = 1040 / (w * s)
        reg = im.crop((int(rx0 * s), int(ry0 * s), int(rx1 * s), int(ry1 * s))).convert('RGB'); reg = reg.resize((max(2, int(reg.width * fct)), max(2, int(reg.height * fct))), Image.LANCZOS)
        reg = ImageEnhance.Contrast(reg).enhance(1.08); regp = out + '.reg.png'; reg.save(regp)
        fw = min(int(w * s * fct), reg.width - 2) // 2 * 2; fh = min(int(h * s * fct), reg.height - 2) // 2 * 2
        xs, ys = (x - rx0) * s * fct, (y - ry0) * s * fct; xe, ye = (x2 - rx0) * s * fct, (y2 - ry0) * s * fct
        wc = im.crop((int(x * s), int(y * s), int((x + w) * s), int((y + h) * s))).convert('RGB').resize((1080, 1344)).filter(ImageFilter.GaussianBlur(30)); wc = ImageEnhance.Brightness(wc).enhance(0.42)
        bgp = out + '.bg.png'; wc.save(bgp)
        fc = (f"[1:v]crop={fw}:{fh}:x='min({xs:.1f}+({xe:.1f}-{xs:.1f})*t/{d:.3f},iw-{fw})':y='min({ys:.1f}+({ye:.1f}-{ys:.1f})*t/{d:.3f},ih-{fh})'[f];[0:v][f]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]")
        sh(['ffmpeg', '-v', 'error', '-y', '-loop', '1', '-framerate', str(FPS), '-t', f'{d + 0.2:.3f}', '-i', bgp, '-loop', '1', '-framerate', str(FPS), '-t', f'{d + 0.2:.3f}', '-i', regp, '-filter_complex', fc, '-map', '[v]', '-frames:v', str(nf)] + ENC + [out])
def build():
    if WHICH == 'A': ra1_words()
    make_cards(); units = UNITS[WHICH]; names = []; ass = HEAD; t_abs = 2.0; auds = []
    for k, u in enumerate(units):
        d = u['b'] - u['a']; nf = int(math.ceil((d + GAP) * FPS - 1e-6)); D = nf / FPS
        # pictures: each unit's pictures share D evenly (pictures are listed with weights = their listed duration)
        wts = [p[3] if p[0] == 'v' else 1.0 for p in u['pics']]; tw = sum(wts); cum = 0; bnd = [0]
        for w_ in wts: cum += w_; bnd.append(int(round(D * FPS * cum / tw)))
        for j, p in enumerate(u['pics']):
            dd = (bnd[j + 1] - bnd[j]) / FPS; out = f'{SD}/u{k}_{j}.mp4'; pic_video(p, dd, out); names.append(out)
        # captions for this unit
        ws = words_for(u)
        chs = chunks(ws)
        for ci, ch in enumerate(chs):
            a = max(0, ch[0][1]); b = min(D, ch[-1][2] + 0.12)
            if ci + 1 < len(chs): b = min(b, max(a + 0.2, chs[ci + 1][0][1] - 0.02))
            ass += f"Dialogue: 0,{ts(a + t_abs)},{ts(b + t_abs)},Cap,,0,0,0,,{two(' '.join(x[0] for x in ch))}\n"
        # audio: narr.wav cut
        src = PL[u['id']]; st = src['s'] + u['a']
        auds.append((f'{SD}/a{k}.wav', st, d, D, u['id'] == 'RA1'))
        t_abs += D
    story_len = t_abs - 2.0
    ass += f"Dialogue: 0,{ts(2.0)},{ts(2.0 + story_len)},Cred,,0,0,0,,{CRED[WHICH]}\n"
    open(SD + '/cap.ass', 'w').write(ass)
    # story video: concat pictures, apply captions on 1080x1920 canvas
    open(SD + '/pl.txt', 'w').write(''.join(f"file '{n}'\n" for n in names))
    sh(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', SD + '/pl.txt', '-c', 'copy', SD + '/band.mp4'])
    sh(['ffmpeg', '-v', 'error', '-y', '-i', SD + '/band.mp4', '-vf', f"pad=1080:1920:0:0:black,setpts=PTS+2.0/TB,ass={SD}/cap.ass:fontsdir={FD},setpts=PTS-2.0/TB,format=yuv420p", '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', SD + '/story.mp4'])
    # cards
    tail = 3.0
    sh(['ffmpeg', '-v', 'error', '-y', '-loop', '1', '-t', '2', '-i', SD + '/open.png', '-vf', f'fps={FPS},format=yuv420p', '-c:v', 'libx264', '-crf', '18', SD + '/open.mp4'])
    sh(['ffmpeg', '-v', 'error', '-y', '-loop', '1', '-t', str(tail), '-i', SD + '/close.png', '-vf', f'fps={FPS},fade=t=in:d=0.3,fade=t=out:st={tail - 0.5}:d=0.5,format=yuv420p', '-c:v', 'libx264', '-crf', '18', SD + '/close_x.mp4'])
    open(SD + '/vl.txt', 'w').write(f"file '{SD}/open.mp4'\nfile '{SD}/story.mp4'\nfile '{SD}/close_x.mp4'\n")
    sh(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', SD + '/vl.txt', '-c', 'copy', SD + '/video.mp4'])
    # audio: voice cuts (narr.wav) + bed
    import numpy as np, wave
    SR = 44100; total = 2.0 + story_len + tail; N = int(total * SR); vo = np.zeros(N, dtype=np.float32); bedg = np.ones(N, dtype=np.float32)
    def rd(p):
        w = wave.open(p); x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768; w.close(); return x
    t = 2.0
    for (pth, st, d, D, real) in auds:
        sh(['ffmpeg', '-v', 'error', '-y', '-ss', f'{st:.3f}', '-t', f'{d:.3f}', '-i', 'narr.wav', '-af', 'afade=t=in:d=0.02,afade=t=out:st=' + f'{max(d - 0.05, 0):.3f}' + ':d=0.05', '-ar', str(SR), '-ac', '1', '-c:a', 'pcm_s16le', pth])
        x = rd(pth); o = int(t * SR); vo[o:o + len(x)] += x[:N - o]
        if real: a = o; b = o + len(x); rp = int(0.3 * SR); bedg[a:b] = 0; bedg[max(a - rp, 0):a] = np.linspace(1, 0, a - max(a - rp, 0)); bedg[b:b + rp] = np.linspace(0, 1, len(bedg[b:b + rp]))
        t += D
    sh(['ffmpeg', '-v', 'error', '-y', '-ss', '30', '-i', 'mus/bed.wav', '-af', f'aresample={SR},aformat=channel_layouts=mono,atrim=0:{total:.2f},afade=t=in:d=0.5,afade=t=out:st={total - 3.0:.2f}:d=3.0', '-c:a', 'pcm_s16le', SD + '/bed.wav'])
    bed = rd(SD + '/bed.wav'); bed = np.pad(bed, (0, max(0, N - len(bed))))[:N] * 10 ** (-3.3 / 20)
    # closing voice: flat take, one constant gain, starts 0.5 s into the closing card; music under it, music-only fade
    sh(['ffmpeg', '-v', 'error', '-y', '-i', FLAT, '-ar', str(SR), '-ac', '1', '-c:a', 'pcm_s16le', SD + '/flat.wav'])
    fl = rd(SD + '/flat.wav'); rms = float(np.sqrt(np.mean(fl ** 2)) + 1e-9); gain = 0.11 / rms; fl = fl * gain   # single constant gain
    o = int((2.0 + story_len + 0.5) * SR); vo[o:o + len(fl)] += fl[:N - o]
    mix = vo + bed * bedg; pk = float(np.max(np.abs(mix))); 
    if pk > 0.95: mix *= 0.95 / pk
    w = wave.open(SD + '/all.wav', 'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(mix, -1, 1) * 32767).astype(np.int16).tobytes()); w.close()
    out = f'{SD}/marilyn_short_{WHICH}.mp4'
    sh(['ffmpeg', '-v', 'error', '-y', '-i', SD + '/video.mp4', '-i', SD + '/all.wav', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', '-shortest', '-metadata', f'title={TITLE}', '-movflags', '+faststart', out])
    print(WHICH, 'story', round(story_len, 2), 'total', round(total, 2), out)
build()
