# Shot map and event order for the Marilyn Monroe LTS long. Alto units are Library of Congress ALTO coordinates (page 18681 x 29028).
IMG = "/tmp/mw/src/img"
PAGES = {  # key: (file, alto page width)
 "A1": (f"{IMG}/e0806_A1.jpg", 18681), "A8": (f"{IMG}/e0806_A8.jpg", 18627), "A10": (f"{IMG}/e0806_A10.jpg", 18681), "A6": (f"{IMG}/e0808_A6.jpg", 18561),
 "F1": (f"{IMG}/funh-1.png", None), "F3": (f"{IMG}/funh-3.png", None)}
LBL = {
 "A1": "Evening Star, Washington, 6 Aug 1962, p. A-1 (Library of Congress)",
 "A8": "Evening Star, Washington, 6 Aug 1962, p. A-8 (Library of Congress)",
 "A10": "Evening Star, Washington, 6 Aug 1962, p. A-10 (Library of Congress)",
 "A6": "Evening Star, Washington, 8 Aug 1962, p. A-6 (Library of Congress)",
 "F1": "Funeral service programme, 8 Aug 1962 (California Revealed)",
 "F3": "Eulogy text, funeral programme, 8 Aug 1962 (California Revealed)",
 "SK": "The Jack Benny Program, 13 Sep 1953 (archive.org)",
 "KO": "US Army, The Big Picture, Korea, Feb 1954 (via Periscope Film)",
 "HB": "Madison Square Garden, 19 May 1962 (archive.org, Producers Library mark)",
 "ST": "Screen test, Something's Got to Give, Apr 1962 (archive.org)",
}
# page shots: ('p', page, (x,y,w,h) start, (x,y) end or None, weight, label)   alto units (F pages: pixels)
def P(pg, win, end=None, w=1.0, lab=None, ill=False): return ("p", pg, win, end, w, (("Illustrative: " if ill else "") + (lab or LBL[pg])))
# video shots: ('v', clip, ss, dur(weight), label, crop or None)
def V(clip, ss, d, lab, crop=None, still=False): return ("v", clip, ss, d, lab, crop, still)
KO_CROP = "crop=638:392:108:0"
def SK(ss, d): return V("sk", ss, d, LBL["SK"])
def IV(ss, d): return V("iv", ss, d, LBL["SK"])
def KO(ss, d): return V("ko", ss, d, LBL["KO"], KO_CROP)
def HB(ss, d): return V("hb", ss, d, LBL["HB"])
def ST(ss, d, lab=None): return V("st", ss, d, lab or LBL["ST"])
HEAD_A1 = (3000, 3480, 5900, 1280)

LGL = "The Legend of Marilyn Monroe, 1966 documentary (archive.org)"
def LG(c, ss, d, lab=None, still=False): return V(c, ss, d, lab or LGL, None, still)
def T(c, ss, d, film): return V(c, ss, d, film + ", trailer (archive.org)")
HBL = "Madison Square Garden, 19 May 1962 (The Legend of Marilyn Monroe, 1966 documentary)"
FUN = "Funeral, Westwood, 8 Aug 1962 (The Legend of Marilyn Monroe, 1966 documentary)"
def FU(ss, d): return V("lgJ", ss, d, FUN)
NIA, GPB, HTM, RON, SYI, BUS, SLH = "Niagara (1953)", "Gentlemen Prefer Blondes (1953)", "How to Marry a Millionaire (1953)", "River of No Return (1954)", "The Seven Year Itch (1955)", "Bus Stop (1956)", "Some Like It Hot (1959)"
M = {
 "C1": [P("A1", HEAD_A1, (3000, 3430), 3.0), LG("lgE", 5.5, 2.5), LG("lgB", 44.5, 3.0)],
 "C2": [FU(3.0, 3.4), FU(36.0, 3.4)],
 "C3": [LG("lgH", 24, 2.4, HBL), T("tG", 4, 2.4, GPB), T("tN", 36, 2.4, NIA)],
 "1.1": [P("A1", (2900, 6400, 2300, 860), None, 3.0), LG("lgA", 0, 3.1), LG("lgA", 6, 3.1)],
 "1.2": [LG("lgA", 30, 4.5), P("A10", (2900, 22650, 2500, 1700), (2900, 22750), 3.5), LG("lgA", 3, 3.0), LG("lgA", 24, 4.3)],
 "1.3": [P("A8", (1000, 8300, 2500, 1800), (1000, 8420), 3.0), LG("lgB", 27, 3.1), LG("lgB", 21, 3.2)],
 "1.3a": [LG("lgB", 0, 3.6), LG("lgB", 6, 3.6), LG("lgB", 12, 3.6)],
 "1.3m": [LG("lgB", 36, 4.4), LG("lgB", 18, 4.4), LG("lgA", 12, 4.4)],
 "1.4": [SK(30, 4.9), SK(38, 4.9)],
 "1.5a": [LG("lgC", 6, 3.0), LG("lgC", 11, 3.0), LG("lgC", 18, 2.7)],
 "1.5": [LG("lgD", 6, 3.0), KO(7.5, 3.0), KO(10.5, 3.0), LG("lgD", 54, 2.8), LG("lgD", 21, 2.8)],
 "1.5b": [LG("lgF", 3, 3.4), LG("lgF", 27, 3.4)],
 "2.1": [T("tN", 32, 3.0, NIA), T("tG", 4, 3.0, GPB), T("tH", 80, 3.3, HTM)],
 "2.1b": [T("tG", 116, 3.3, GPB), T("tG", 120, 3.3, GPB), T("tG", 128, 3.3, GPB)],
 "2.2": [T("tR", 24, 3.0, RON), LG("lgE", 15, 3.2), LG("lgE", 18, 3.1), T("tI", 4, 3.0, SYI)],
 "2.3": [LG("lgG", 6, 2.9, "Actors Studio, New York (The Legend of Marilyn Monroe, 1966 documentary)"), LG("lgG", 12, 2.9, "Actors Studio, New York (The Legend of Marilyn Monroe, 1966 documentary)"), LG("lgG", 15, 2.9, "Actors Studio, New York (The Legend of Marilyn Monroe, 1966 documentary)")],
 "2.4": [T("tB", 20, 3.3, BUS), T("tB", 52, 3.3, BUS), T("tS", 56, 3.3, SLH), T("tS", 104, 3.3, SLH)],
 "3.1": [LG("lgM", 36, 3.7), LG("lgM", 69, 3.7), LG("lgM", 108, 3.7)],
 "3.2": [ST(0.0, 3.2), ST(15.0, 3.2), ST(21.0, 3.2)],
 "3.3": [LG("lgH", 0, 3.7, HBL), LG("lgH", 22, 3.8, HBL), LG("lgH", 40, 3.8, HBL)],
 "3.4": [LG("lgI", 9, 4.5), LG("lgI", 15, 4.5), LG("lgI", 21, 4.5)],
 "3.5": [LG("lgI", 0, 3.2, "Newspaper headline, filmed (The Legend of Marilyn Monroe, 1966 documentary)", True), LG("lgI", 9, 3.6), LG("lgI", 24, 3.7)],
 "3.6": [LG("lgK", 0, 3.7, "Crypt, Westwood Village (The Legend of Marilyn Monroe, 1966 documentary)")],
 "4.1": [P("A10", (3000, 16210, 2300, 1300), (3000, 16260), 3.0), LG("lgM", 0, 3.0), LG("lgE", 9, 3.9)],
 "4.2": [P("A6", (13400, 11000, 2500, 2200), (13400, 11150), 3.0), ST(27.0, 4.5), ST(43.0, 5.4)],
 "4.3": [P("A10", (3000, 16210, 2300, 1300), (3000, 16260), 3.0), ST(7.0, 4.0)],
 "4.4": [LG("lgI", 3, 3.5, "Illustrative: house exterior (The Legend of Marilyn Monroe, 1966 documentary)"), LG("lgI", 6, 4.0, "Illustrative: house exterior (The Legend of Marilyn Monroe, 1966 documentary)")],
 "4.5": [P("A1", HEAD_A1, (3050, 3520), 4.0), LG("lgF", 15, 2.4), LG("lgF", 21, 2.4)],
 "4.6": [P("A1", (2900, 8800, 2200, 1300), (2900, 8900), 3.5), ST(35.0, 2.2), LG("lgA", 36, 2.3)],
 "4.7": [FU(0, 3.3), FU(3, 3.3), FU(6, 3.3), FU(45, 3.3)],
 "4.8": [P("F3", (0, 60, 1445, 900), (0, 300), 3.5), FU(33, 3.7), FU(39, 3.7), FU(54, 3.7)],
 "4.8b": [LG("lgK", 21, 2.5, "Storage warehouse, New York (The Legend of Marilyn Monroe, 1966 documentary)"), LG("lgK", 30, 3.4, "A white piano in storage (The Legend of Marilyn Monroe, 1966 documentary)"), LG("lgK", 38, 3.4, "A white piano in storage (The Legend of Marilyn Monroe, 1966 documentary)")],
 "4.9": [LG("lgK", 3, 2.8, "Crypt, Westwood Village (The Legend of Marilyn Monroe, 1966 documentary)"), LG("lgK", 12, 2.8, "Crypt, Westwood Village (The Legend of Marilyn Monroe, 1966 documentary)"), FU(57, 2.8)],
 "4.10": [P("A10", (900, 10550, 4100, 1450), (950, 10560), 3.0, ill=True), LG("lgK", 6, 4.3, "Crypt, Westwood Village (The Legend of Marilyn Monroe, 1966 documentary)"), LG("lgK", 15, 4.3, "Crypt, Westwood Village (The Legend of Marilyn Monroe, 1966 documentary)")],
 "Z1": [LG("lgA", 15, 3.6), LG("lgA", 21, 3.7)],
 "Z2": [T("tS", 44, 2.5, SLH), T("tN", 40, 2.5, NIA)],
}
MCL = "Marilyn Monroe, Edgar Bergen and Charlie McCarthy, radio, Nov 1952 (archive.org; audio only, picture: film footage)"
RA = {
 "RA1": dict(after="1.4", aud="iv", ss=8.95, dur=6.65, pic=("iv", 8.95), label="Marilyn Monroe and Jack Benny, 13 Sep 1953 (The Jack Benny Program)"),
 "RA2": dict(after="1.4", aud="iv", ss=22.0, dur=10.35, pic=("iv", 22.0), label="Marilyn Monroe and Jack Benny, 13 Sep 1953 (The Jack Benny Program)"),
 "RA2b": dict(after="1.4", aud="iv", ss=61.9, dur=9.05, pic=("iv", 61.9), label="Marilyn Monroe and Jack Benny, 13 Sep 1953 (The Jack Benny Program)"),
 "RAMC": dict(after="1.3m", aud="mc", ss=1155.3, dur=10.0, pic=("lgB", 39.0), label=MCL),
 "RA3": dict(after="3.3", aud="hb", ss=41.2, dur=24.8, pic=("hb", 41.2), label="Marilyn Monroe, Madison Square Garden, 19 May 1962 (archive.org, Producers Library mark)"),
 "RA4": dict(after="3.4", aud="schiller", ss=5.75, dur=4.65, pic=("st", 31.0), label="Lawrence Schiller, photographer, Fox News, 2012 (audio only; picture: April 1962 costume test)"),
}
BEATS = {
 "BK": dict(items=[LG("lgD", 36, 3.5), LG("lgD", 60, 3.5)]),
 "BHB": dict(items=[LG("lgH", 96, 3.5, HBL), LG("lgH", 102, 3.5, HBL)]),
 "BC": dict(items=[T("tS", 72, 3.5, SLH), T("tS", 92, 3.5, SLH)]),
 "BEND": dict(items=[LG("lgH", 76, 3.6, HBL), LG("lgH", 84, 3.6, HBL)]),
}
SEQ = [("card","open"),("line","C1"),("line","C2"),("line","C3"),
 ("card","1"),("line","1.1"),("line","1.2"),("line","1.3"),("line","1.3a"),("line","1.3m"),("ra","RAMC"),("line","1.4"),("ra","RA1"),("ra","RA2"),("ra","RA2b"),("line","1.5a"),("line","1.5"),("beat","BK"),("line","1.5b"),
 ("card","2"),("line","2.1"),("line","2.1b"),("line","2.2"),("line","2.3"),("line","2.4"),("beat","BC"),
 ("card","3"),("line","3.1"),("line","3.2"),("line","3.3"),("ra","RA3"),("beat","BHB"),("line","3.4"),("ra","RA4"),("line","3.5"),("line","3.6"),
 ("card","4"),("line","4.1"),("line","4.2"),("line","4.3"),("line","4.4"),("line","4.5"),("line","4.6"),("line","4.7"),("line","4.8"),("line","4.8b"),("line","4.9"),("line","4.10"),("beat","BEND"),("line","Z1"),("line","Z2"),("card","close")]
