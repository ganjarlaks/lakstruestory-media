import re,sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ttsprep_base as _b
_b.TIMES={"5:15":"five fifteen"}
_b.RESP=[]
RESP=[("DiMaggio","Dih-Maj-ee-oh"),("Zanuck","Zan-uck"),("Curphey","Cur-fee"),("Schiller","Shiller"),("Greenson","Green-son"),("Strasberg","Strahs-berg"),("Twentieth Century-Fox","Twentieth Century Fox"),("Brentwood","Brent-wood"),("theatre","theater")]
def tts(t):
    t=t.replace("5:15","five fifteen")
    t=t.replace("US Army","U S Army")
    t=t.replace(" 36."," thirty-six.")
    for a,b in RESP: t=t.replace(a,b)
    return _b.tts(t)
if __name__=="__main__":
    exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),"lines.py")).read())
    for i,c,tx in L: print(i,"|",tts(tx))
